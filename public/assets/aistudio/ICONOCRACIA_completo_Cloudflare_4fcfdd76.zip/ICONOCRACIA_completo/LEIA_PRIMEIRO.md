# ICONOCRACIA · pacote completo

Preparado em 13 de novembro de 2026 para Ana Vitória Vanzin Mendes.

Site publicado: https://iconocracia-apresentacoes.anavanzin.workers.dev/

Comunicação em italiano: https://iconocracia-apresentacoes.anavanzin.workers.dev/representacao/it/#slide-01

## Abrir sem internet

Abra `offline/ICONOCRACIA_duas_apresentacoes.html` no navegador. O arquivo incorpora os textos, as fontes, os estilos e a navegação. Não exige instalação. Links para fontes externas continuam exigindo internet. Um link local copiado só funciona em outro computador se esse computador também tiver o arquivo.

## Conteúdo do pacote

| Pasta | Conteúdo |
| --- | --- |
| `site/` | HTML, CSS, JavaScript, dados das dez edições e fontes licenciadas. É a única pasta incorporada ao Worker público. |
| `offline/` | Arquivo HTML único para leitura e apresentação sem conexão. |
| `worker/` | Worker completo, handler editável, metadados de implantação e registro da publicação. |
| `scripts/` | Geração do Worker, geração do HTML offline e publicação pela API oficial. |
| `tests/` | Verificação dos arquivos servidos, das dez rotas e das respostas HTTP. |
| `materiais_originais/` | Pacote original com PPTX, PDF, HTML, roteiro e notas de cotejo. Estes arquivos não foram publicados no Worker. |
| `referencias_visuais/` | Cinco imagens de referência, incluindo as três propostas de redesign. Não são telas implementadas. |

O site contém duas apresentações: percurso da pesquisa, com 14 slides, e comunicação sobre representação e autenticação, com 13. Há versões em português, inglês, francês, italiano e neerlandês. As traduções e as pendências documentais conservam a identificação de edição de trabalho.

## O que foi entregue

Esta publicação usa o desenho existente. A composição com entrada da opção 1 e leitor da opção 3 continua proposta, não implementada. Os registros dos slides foram preservados.

Foram corrigidos nesta cópia:

- Foco de teclado e cor de hover no cartão vinho.
- Navegação por setas quando um botão permanece com foco. As setas continuam bloqueadas dentro de diálogos e campos editáveis.
- Limpeza do conteúdo de impressão ao mudar de rota, evitando imprimir slides anteriores em uma página inválida.
- Texto que chamava o site de privado, pois este endereço Cloudflare é público.

O projeto original do Sites não foi alterado. O novo Worker foi criado com outro nome; os Workers anteriores da conta não foram substituídos.

## Editar e gerar novamente

Altere textos em `site/data/`, interface em `site/interface.js`, comportamento em `site/app.js` e estilos em `site/style.css`. Use Node.js 20 ou posterior e Python 3. Não há dependências npm para instalar.

```sh
npm run build
npm run build:offline
npm run check
```

O comando `build` recria `worker/worker.mjs` apenas a partir de `site/` e `worker/handler.mjs`. Não edite manualmente o Worker gerado. `build:offline` recria o HTML em `offline/` a partir dos mesmos arquivos do site.

## Republicar na Cloudflare

Leia `DEPLOY_CLOUDFLARE.md`. O Worker já está publicado; estes passos servem para futuras alterações ou para criar uma cópia. Não há tokens, credenciais ou configuração de login no ZIP.

## Verificação e limites

Os três testes automatizados passaram. Eles verificam os bytes dos 30 arquivos públicos, as dez rotas, os dados dos 135 registros de slides, respostas a URLs inexistentes, redirecionamentos, HEAD e validação de cache. A paridade dos slides entre o site e o HTML offline foi conferida separadamente. Os materiais de origem não fazem parte do manifesto público do Worker.

No endereço publicado foram conferidos: entrada, abertura direta da comunicação italiana, avanço por teclado após focar um botão e troca para português preservando o slide 2. O navegador de verificação não permitiu ativar tela cheia; a interface mostrou o aviso correspondente. Impressão paginada, uso por leitor de tela e uma nova rodada completa em celular não foram verificados nesta entrega.

As imagens de pesquisa permanecem ausentes do leitor, conforme as pendências existentes de identificação, legenda e direitos. O pacote não representa nova aprovação acadêmica ou revisão de originalidade.

As fontes usadas estão acompanhadas de `site/fonts/LICENSE.txt`.
