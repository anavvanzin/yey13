// Appended after the generated assets constant; only site/ files are included.
export default {
  async fetch(request) {
    if (!['GET','HEAD'].includes(request.method)) {
      return new Response('Method not allowed', {status:405, headers:{Allow:'GET, HEAD'}});
    }
    const url = new URL(request.url);
    let pathname;
    try { pathname = decodeURIComponent(url.pathname); }
    catch { return new Response('Bad request', {status:400}); }
    if (!Object.hasOwn(assets,pathname) && Object.hasOwn(assets,pathname+'/index.html')) {
      url.pathname += '/';
      return Response.redirect(url.toString(),308);
    }
    const key = pathname.endsWith('/') ? pathname+'index.html' : pathname;
    const asset = Object.hasOwn(assets,key) ? assets[key] : null;
    if (!asset) return new Response(request.method==='HEAD'?null:'Not found',{status:404,headers:{'Content-Type':'text/plain; charset=utf-8'}});
    const headers = new Headers({
      'Content-Type':asset.contentType,
      'ETag':asset.etag,
      'Cache-Control':'public, max-age=0, must-revalidate',
      'X-Content-Type-Options':'nosniff',
      'X-Robots-Tag':'noindex, nofollow'
    });
    const match = request.headers.get('If-None-Match');
    if (match && match.split(',').some(value=>value.trim()==='*'||value.trim().replace(/^W\//,'')===asset.etag)) return new Response(null,{status:304,headers});
    const body = request.method==='HEAD' ? null : asset.binary ? Uint8Array.from(atob(asset.body),c=>c.charCodeAt(0)) : asset.body;
    return new Response(body,{status:200,headers});
  }
};
