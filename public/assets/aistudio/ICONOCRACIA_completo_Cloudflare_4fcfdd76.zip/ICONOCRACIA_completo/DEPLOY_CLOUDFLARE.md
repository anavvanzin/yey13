# Publicar ou atualizar o Worker

Este pacote usa um Worker ES module independente, com os arquivos públicos incorporados ao módulo. Não precisa de banco de dados, KV, R2 ou um servidor de origem. A distribuição é pequena; esta forma também permite publicar o arquivo completo pelo editor da Cloudflare.

## Pelo painel

1. Na Cloudflare, abra Workers & Pages e crie um Worker, ou abra `iconocracia-apresentacoes` para atualizar a publicação existente.
2. Abra o editor de código e substitua o código do módulo principal pelo conteúdo completo de `worker/worker.mjs`.
3. Mantenha a data de compatibilidade `2026-11-13` e publique. O arquivo `worker/metadata.json` registra a configuração usada nesta entrega.
4. Habilite a rota workers.dev se desejar usar o endereço padrão do Worker.

Copie apenas o módulo gerado. Não envie `materiais_originais/` como arquivos públicos.

## Pela API oficial

O script `scripts/deploy-api.mjs` usa a API da Cloudflare diretamente e não depende de pacotes externos. Precisa de Node.js 20 ou posterior. Defina `CLOUDFLARE_ACCOUNT_ID` e `CLOUDFLARE_API_TOKEN` no ambiente de execução; o token precisa de permissão para editar Workers na conta escolhida. Nunca coloque o token no código ou no ZIP.

Para criar uma nova cópia, defina também `CLOUDFLARE_WORKER_NAME` com um nome novo e execute:

```sh
npm run build
npm run build:offline
npm run check
npm run deploy:api
```

O script recusa substituir um Worker existente sem a opção explícita `--replace`. Para atualizar a publicação existente depois de conferir o nome e a conta:

```sh
npm run deploy:api -- --replace
```

O script habilita o endereço público workers.dev e mantém os endereços de prévia desabilitados. Ele não cria nem altera DNS ou domínios personalizados. O HTML contém `noindex` e a resposta HTTP reforça essa indicação, mas isso não restringe acesso ao endereço público.

## Fontes técnicas consultadas

- [Upload de um Worker ES module](https://developers.cloudflare.com/workers/configuration/multipart-upload-metadata/)
- [Publicação pela API](https://developers.cloudflare.com/workers/platform/infrastructure-as-code/)
- [Endereços workers.dev](https://developers.cloudflare.com/workers/configuration/routing/workers-dev/)

O ZIP usa a mesma fonte do módulo publicado. O registro em `worker/deployment.json` identifica a implantação desta entrega; não contém credenciais.
