# ICONOCRACIA | Duas apresentações, cinco idiomas
Pacote privado de trabalho. Nenhum arquivo constitui aprovação para publicação.

- **01_TRAJETO**: cópia editável reconstruída e conteúdo JSON extraídos do script de composição da revisão de 14 slides. O PowerPoint não é uma exportação nativa; a formatação pode variar. A versão visual canônica é https://chatgpt.com/space/page_565b237a1e78819182b05105e41d8a85. As notas são material interno.
- **02_REPRESENTACAO**: HTML de 13 slides enviado para revisão; PDF e PPTX Enhanced e roteiro inglês/italiano são variantes anteriores, apenas para referência. Nenhuma delas deve substituir a versão aprovada pela autora.
- **03_REVISAO**: cotejo slide a slide com correções e checklist. Não publicar essa pasta.
- **PROMPT_SITE.md**: instruções de montagem independentes de plataforma.

O ZIP não contém site publicado, dez traduções prontas ou QR final. No site final, exponha somente conteúdo e créditos aprovados, nunca este ZIP.
