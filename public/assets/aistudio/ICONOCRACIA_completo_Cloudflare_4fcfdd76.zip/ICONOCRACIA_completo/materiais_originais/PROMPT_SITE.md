# Prompt de construção
Crie um site estático para as duas apresentações da ICONOCRACIA no evento Saberes França–Brasil da UFSC. O site deve funcionar sem login, banco de dados ou tradução em tempo real. Não dependa de Lovable ou outro construtor. Entregue código e instruções de deploy (Cloudflare é opção, não exigência). Não publique antes da aprovação da autora.

## Fontes
1. **O que a pesquisa me fez abandonar · Um ano de ICONOCRACIA**: use a revisão de 14 slides. Preserve o percurso, as comparações, o índice abandonado, a volta de Panofsky ao lado de Warburg e a explicação simples de GitHub. Use a Page canônica para conferir a aparência.
2. **Between Representation and Authentication**: prepare prévia corrigida a partir do HTML de 13 slides e do cotejo. Não silencie divergências com as variantes antigas. Marque imagens/créditos e legendas pendentes, e peça a versão canônica final. Preserve as diferenças entre atribuição e prova de compra, entre ouro como garantia da emissão e curso legal geral, entre equivalência material e fabricação com autoridade legítima. Cite o art. 10 dos estatutos anexos ao Decreto 1.227/1890 para as moedas francesas. Distinga Debret 1822 da prancha de 1839.

## Navegação
Entrada em dois cartões, trajeto primeiro e comunicação temática depois. Cada um oferece Português, English, Français, Italiano e Nederlands. Dez edições completas, rotas /trajeto/{pt,en,fr,it,nl}/ e /representacao/{pt,en,fr,it,nl}/. Use âncoras estáveis #slide-01 etc. Trocar idioma mantém apresentação e slide. Sem bandeiras ou redirecionamento automático. Sumário, contador, voltar à entrada, botões grandes, navegação por teclado e histórico do navegador.

## Tradução e design
Traduza títulos, textos, legendas, interface e descrições acessíveis em cada edição. Preserve ordem, nomes, datas, fontes, identificadores e grau de certeza. Mantenha originais de citações probatórias e identifique traduções. Mantenha glossário jurídico por idioma, assinalando dúvidas na revisão. Não invente imagens ou fontes.
Atlas aberto: marfim, vinho, tipografia editorial, notas de margem e contrastes visíveis entre versões; use iconocracia.com como referência. Um slide por vez no celular, com texto selecionável e rolagem onde necessário. Foco visível, contraste, redução de movimento, texto alternativo, imagens compactas e sem efeitos que escondam conteúdo.

## Aprovação, QR e entrega
Entregue prévia com inventário, contagens, diferenças da revisão, tradução e direitos pendentes. Só após aprovação publique materiais autorizados em HTTPS estável. Gere um QR único para a entrada em PNG de alta resolução e SVG, preto sobre branco, margem de quatro módulos, sem logotipo sobreposto. Crie um slide final reutilizável com QR, URL escrita e “Duas apresentações, cinco idiomas / Two presentations, five languages”. Sem URL definitiva, marque QR pendente. Entregue código, instruções, URL principal, dez links e QR em ambos formatos. Teste os dez links em janela anônima, trocas de idioma, conteúdo longo, legibilidade no celular e leitura do QR projetado. Se houver PDF, confirme idioma, contagem e cortes.
