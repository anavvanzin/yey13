# Referências visuais, não implementações

As imagens 01, 02 e 03 são as três propostas de design apresentadas anteriormente. As outras duas imagens pertencem à exploração inicial.

A recomendação da revisão foi usar a entrada com fólio da opção 1 e o leitor com sumário lateral da opção 3. Essa direção ainda não foi aplicada ao site nem ao HTML offline deste pacote.

Pendências de produto identificadas: ação explícita para abrir em italiano; preservação da escolha de idioma ao voltar à entrada; distinção entre leitura e projeção; sumário que abre com o slide corrente visível; referências contextuais por slide. São propostas, não funções entregues nesta publicação.
