import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile,readdir} from 'node:fs/promises';
import worker from '../worker/worker.mjs';
const origin='https://example.workers.dev';

test('all hosted files preserve their bytes and MIME type',async()=>{
  async function visit(directory,route='') {
    for(const f of await readdir(directory,{withFileTypes:true})) {
      const p=new URL(f.name+(f.isDirectory()?'/':''),directory);
      if(f.isDirectory()) {await visit(p,route+'/'+f.name);continue;}
      const r=await worker.fetch(new Request(origin+route+'/'+f.name));
      assert.equal(r.status,200,route+'/'+f.name);
      assert.deepEqual(Buffer.from(await r.arrayBuffer()),await readFile(p));
      assert.ok(r.headers.get('content-type'));
    }
  }
  await visit(new URL('../site/',import.meta.url));
});
test('all ten deep links have the correct edition data',async()=>{
  for(const deck of ['trajeto','representacao']) for(const lang of ['pt','en','fr','it','nl']) {
    const page=await worker.fetch(new Request(`${origin}/${deck}/${lang}/`));
    assert.equal(page.status,200);
    const r=await worker.fetch(new Request(`${origin}/data/${deck}-${lang}.json`));
    assert.match(r.headers.get('content-type'),/application\/json/);
    const slides=await r.json();
    assert.equal(slides.length,deck==='trajeto'?14:13);
    assert.ok(slides.every(s=>s.title&&Array.isArray(s.blocks)));
  }
});
test('redirects, missing assets, private material, HEAD and cache validation',async()=>{
  assert.equal((await worker.fetch(new Request(origin+'/representacao/it'))).status,308);
  for(const route of ['/data/missing.json','/.git/config','/materiais_originais/LEIA_PRIMEIRO.md','/scripts/deploy-api.mjs','/constructor']) assert.equal((await worker.fetch(new Request(origin+route))).status,404);
  const r=await worker.fetch(new Request(origin+'/'));
  assert.equal(r.status,200);
  assert.equal((await worker.fetch(new Request(origin+'/',{headers:{'If-None-Match':r.headers.get('etag')}}))).status,304);
  assert.equal(await (await worker.fetch(new Request(origin+'/',{method:'HEAD'}))).text(),'');
  assert.equal((await worker.fetch(new Request(origin+'/',{method:'POST'}))).status,405);
});
