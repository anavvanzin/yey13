from pathlib import Path
import json,base64,re,html
root=Path(__file__).resolve().parents[1]
src=root/'site'
out=root/'offline'/'ICONOCRACIA_duas_apresentacoes.html'
css=(src/'style.css').read_text()
for font in (src/'fonts').glob('*.otf'):
 css=css.replace('/fonts/'+font.name, 'data:font/otf;base64,'+base64.b64encode(font.read_bytes()).decode())
all_decks={f'{deck}/{lang}':json.loads((src/'data'/f'{deck}-{lang}.json').read_text()) for deck in ['trajeto','representacao'] for lang in ['pt','en','fr','it','nl']}
editorial=json.loads((src/'data/editorial.json').read_text())
# The downloadable copy has no platform access gate. Describe the artifact accurately.
replacements={
'pt':('Este site de trabalho','Este arquivo de trabalho'),
'en':('This working site','This working file'),
'fr':('Ce site de travail','Ce fichier de travail'),
'it':('Questo sito di lavoro','Questo file di lavoro'),
'nl':('Deze werksite','Dit werkbestand')}
for lang,(old,new) in replacements.items():
 editorial[lang]['edition']=[p.replace(old,new) for p in editorial[lang]['edition']]
# Preserve the original edition's research status in all languages.
bundle=json.dumps({'decks':all_decks,'editorial':editorial},ensure_ascii=False,separators=(',',':')).replace('<','\\u003c')
app=(src/'app.js').read_text()
app=app.replace("let state={deck:null,lang:'pt',slide:0},cache={},slides=[],editorial=null,request=0,lastFocus=null,noticeTimer;", "const bundled=JSON.parse(document.getElementById('embedded-content').textContent);\nlet state={deck:null,lang:'pt',slide:0},cache=bundled.decks,slides=[],editorial=bundled.editorial,request=0,lastFocus=null,noticeTimer;")
start=app.index('function route()')
end=app.index('function languageLinks',start)
app=app[:start]+'''function route(){const hash=location.hash;if(!hash||hash==='#/'||hash==='#main')return {deck:null,lang:'pt',slide:0};const m=hash.match(/^#\\/(trajeto|representacao)\\/(pt|en|fr|it|nl)\\/slide-(\\d+)$/);if(m)return {deck:m[1],lang:m[2],slide:Math.max(0,Number(m[3])-1)};return {deck:'invalid',lang:'pt',slide:0};}
const href=(deck,lang,index=0)=>`#/${deck}/${lang}/slide-${String(index+1).padStart(2,'0')}`;
'''+app[end:]
old="if(!cache[key]){$('#main').innerHTML=`<p class=\"not-found\" role=\"status\">${u.loading}</p>`;const r=await fetch(`/data/${state.deck}-${state.lang}.json`);if(!r.ok)throw Error();cache[key]=await r.json();}"
assert old in app
app=app.replace(old,'if(!cache[key])throw Error();')
old="if(!editorial){const r=await fetch('/data/editorial.json');if(!r.ok)throw Error();editorial=await r.json();}"
assert old in app
app=app.replace(old,'')
app=app.replace('href="/"','href="#/"')
app=app.replace("a.origin===location.origin", "a.getAttribute('href')?.startsWith('#/')")
app=app.replace('navigate(a.pathname+a.hash)','navigate(a.hash)')
# Clipboard restrictions on locally opened files must not make the action fail silently.
app=app.replace("await navigator.clipboard.writeText(location.href);toast(u.copied);", "if(navigator.clipboard?.writeText){await navigator.clipboard.writeText(location.href);}else{const copy=document.createElement('textarea');copy.value=location.href;copy.style.cssText='position:fixed;left:-9999px';document.body.appendChild(copy);copy.select();const ok=document.execCommand('copy');copy.remove();if(!ok)throw Error();}toast(u.copied);")
ui=(src/'interface.js').read_text()
index=(src/'index.html').read_text()
favicon='data:image/svg+xml;base64,'+base64.b64encode((src/'favicon.svg').read_bytes()).decode()
index=index.replace('/favicon.svg',favicon)
index=index.replace('<link rel="stylesheet" href="/style.css">','<style>\n'+css+'\n</style>')
index=index.replace('  <script src="/interface.js" defer></script>\n','').replace('  <script src="/app.js" defer></script>\n','')
license=(src/'fonts/LICENSE.txt').read_text().replace('</script','<\\/script')
index=index.replace('</body>',f'<script type="application/json" id="embedded-content">{bundle}</script>\n<script>\n{ui}\n{app}\n</script>\n<script type="text/plain" id="font-license">{license}</script>\n</body>')
out.write_text(index)
assert 'fetch(' not in app
assert not re.search(r'<(?:script|link)[^>]+(?:src|href)="/',index)
assert all(len(all_decks[d+'/'+l])==(14 if d=='trajeto' else 13) for d in ['trajeto','representacao'] for l in ['pt','en','fr','it','nl'])
print(json.dumps({'path':str(out),'bytes':out.stat().st_size,'editions':len(all_decks),'slides':sum(map(len,all_decks.values())),'external_dependencies':0}))
