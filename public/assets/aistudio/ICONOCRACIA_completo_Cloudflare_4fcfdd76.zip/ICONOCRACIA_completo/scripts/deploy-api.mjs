import {readFile} from 'node:fs/promises';
const token=process.env.CLOUDFLARE_API_TOKEN;
const account=process.env.CLOUDFLARE_ACCOUNT_ID;
const name=process.env.CLOUDFLARE_WORKER_NAME || 'iconocracia-apresentacoes';
if(!token||!account) throw Error('Set CLOUDFLARE_API_TOKEN and CLOUDFLARE_ACCOUNT_ID in your environment. Do not put them in this file.');
if(!/^[a-z0-9_][a-z0-9-_]*$/.test(name)) throw Error('Invalid worker name.');
async function api(endpoint,method='GET',body) {
  const response=await fetch('https://api.cloudflare.com/client/v4'+endpoint,{method,headers:{Authorization:`Bearer ${token}`,...(body&&!(body instanceof FormData)?{'Content-Type':'application/json'}:{})},body:body instanceof FormData?body:body?JSON.stringify(body):undefined});
  const data=await response.json();
  if(!response.ok||!data.success) throw Error(JSON.stringify({status:response.status,errors:data.errors}));
  return data.result;
}
const base=`/accounts/${account}/workers/scripts`;
const list=await api(base);
if(list.some(x=>x.id===name)&&!process.argv.includes('--replace')) throw Error(`Worker ${name} already exists. Review the target, then add --replace to update it.`);
const form=new FormData();
form.append('metadata',new Blob([await readFile(new URL('../worker/metadata.json',import.meta.url),'utf8')],{type:'application/json'}));
form.append('worker.mjs',new Blob([await readFile(new URL('../worker/worker.mjs',import.meta.url))],{type:'application/javascript+module'}),'worker.mjs');
const deployed=await api(base+'/'+name,'PUT',form);
await api(base+'/'+name+'/subdomain','POST',{enabled:true,previews_enabled:false});
const domain=await api(`/accounts/${account}/workers/subdomain`);
console.log(JSON.stringify({worker:name,url:`https://${name}.${domain.subdomain}.workers.dev/`,modified_on:deployed.modified_on},null,2));
