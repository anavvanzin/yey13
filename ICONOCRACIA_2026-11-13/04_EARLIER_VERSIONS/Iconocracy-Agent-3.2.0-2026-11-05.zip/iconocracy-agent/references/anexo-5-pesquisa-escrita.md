# Anexo 5. Pesquisa, escrita e revisão

> Anexo especializado preservado da versão de outubro. Usar com o núcleo atual e
> `metodo-e-fontes.md`. As antigas remissões numeradas a divergências/regras pertencem
> àquela versão histórica: conferir o conflito atual antes de executar. Exemplos,
> números, comandos e ferramentas não são automaticamente fatos ou recursos atuais.

Para cadeias longas, prefira as skills dedicadas quando disponíveis: `academic-pipeline`
(pesquisa → redação → integridade → revisão), `iconocracy-reviewer` e
`academic-writing-reviewer` (revisão e ABNT), `novelty-claim-sweep` (afirmações de
ineditismo). Este anexo fixa o que vale para a tese em qualquer caso.

### PESQUISAR

Modos: `quick` (briefing de 1–2 páginas), `lit-review`, `fact-check`, `socratic`
(clarificar a pergunta), `review` (leitura crítica de um texto), `systematic-review`
(a review Elicit da reformulação já existe; partir dela em vez de recomeçar).

#### Hierarquia de evidência (critério historiográfico)

A força de uma afirmação depende da fonte que a sustenta, nesta ordem:

1. **Fonte primária consultada** (objeto, documento de arquivo com cota, edição
   original ou fac-símile), com localização verificável.
2. **Edição crítica ou tradução de referência**, com edição e paginação identificadas.
3. **Literatura especializada** (monografia, artigo com revisão por pares, capítulo),
   com página conferida no exemplar usado.
4. **Obras de síntese, manuais, catálogos de acervo** (úteis para orientação;
   examinar a responsabilidade institucional e a base indicada para cada afirmação).
5. **Web não institucional, verbetes, IA** (só como pista; nunca como fundamento).

Ao citar, registrar a edição e a paginação efetivamente usadas no projeto. Contradições
entre fontes são expostas, com a razão para preferir uma delas. Usar estados de claims conforme schema vigente, explicitando suporte e limites.
A antiga heurística de duas fontes não é regra universal: adequação, independência e
alcance da fonte determinam o que é defensável. Não promover um claim apenas por contagem.

A hierarquia é relativa à afirmação: um registro institucional de acervo pode sustentar
metadados do objeto sem demonstrar intenção, recepção ou interpretação. Contar fontes
não substitui crítica; cópias, traduções ou relatórios dependentes não são confirmações
independentes. Resumos e snippets não certificam páginas ou citações do texto integral.

Relatórios gerados no repositório e respostas de IA ficam no nível 5 até que suas
citações sejam conferidas na fonte. Para cada afirmação que sustente a hipótese central,
procure ao menos uma contraprova ou explicação concorrente e registre o resultado:
encontrada, não encontrada ou não buscada.

#### Controle dos insumos recebidos em 18/10/2026

Ler o Anexo 10 antes de reutilizar os oito anexos como fontes ou protocolo. A edição
revista do guia filosófico melhora a original, sem validar seus números, recorte ou
referências. No arquivo 02, a passagem atribuída a Jane Eyre com `Android-like` permanece
suspeita; não a citar sem texto/edição/página. Conferir cronologias, causalidade e edições
nos estudos de caso; repetição entre relatórios não verifica uma afirmação.

Para mediação jurídica, usar o Anexo 8. Para literatura, lamento, raça, gênero e sátira,
usar o Anexo 9. Distinguir fonte consultada, obra apenas identificada e pista não
localizada; não completar bibliografia ou localizador de memória. Manter a preferência
pela edição de Mondzain registrada no projeto e conferir qual obra ela designa; ano e
páginas de 2005 não se convertem automaticamente em 2002.

#### Handoff para REDIGIR

Pergunta de pesquisa delimitada, bibliografia anotada (com edição e páginas), síntese e
lista de lacunas e pontos a verificar no exemplar físico.

### REDIGIR

Modos: `plan` (capítulo a capítulo, em diálogo), `full`, `revision`, `citation-check`,
`format-convert` (ABNT ↔ APA ↔ Chicago), `bilingual-abstract`, `writing-polish`.

Registro: português brasileiro acadêmico, prosa ensaística em parágrafos, vocabulário
historiográfico preciso, Markdown compatível com Pandoc. Não redija a hipótese central, a
tipologia de regimes nem a de recusas como resultado; se o texto precisar de uma escolha
teórica ainda aberta, marque `[DECISÃO: ...]` no ponto. Descreva o corpus como catálogo e
instantâneo de trabalho, com números lidos do ledger vigente e datados; números de fases
anteriores aparecem como instantâneo histórico.

### REVISAR

Perspectivas: método (iconológico e historiográfico), domínio (história da arte e do
direito), advogada do diabo (contra a hipótese em curso, qualquer que seja), escrita
(clareza, coesão, estabilidade terminológica), ética e representação.

Regras: preservar a voz de Ana e o argumento pretendido; marcar cada ponto como `[estilo]`
ou `[conceito/conteúdo]`; não acrescentar afirmação substantiva sem sustentação; apontar
presentismo, comparação forçada, circularidade e instabilidade conceitual só com evidência
concreta, citando o trecho; polimento terminológico fino só quando Ana pedir ou perto da
defesa.

Saída: pontos por gravidade, com trecho, problema, correção proposta e tipo de alteração;
decisão editorial (aceitar, ajustes pontuais, reestruturação, rejeitar). Rubricas numéricas
só se Ana pedir.

### PIPELINE

PESQUISAR → REDIGIR → verificação de integridade citacional → REVISAR → REDIGIR
(revisão) → REVISAR → formatação final. Delimitar a entrega e os pontos de decisão; continuar
correções autorizadas até os critérios de conclusão, sem rodadas ornamentais.
