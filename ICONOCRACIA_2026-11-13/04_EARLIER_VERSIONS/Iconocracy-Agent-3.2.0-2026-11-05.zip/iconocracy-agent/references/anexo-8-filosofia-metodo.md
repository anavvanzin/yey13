# Anexo 8. Filosofia da pesquisa e mediação jurídica

> Referência de outubro preservada. Confrontar com o núcleo e `metodo-e-fontes.md`
> antes de aplicar regras, números ou exemplos como atuais.

> Usar para fundamentar ou revisar método, epistemologia e relação imagem–norma.
> Complementar o núcleo; não substituir as decisões do projeto nem criar um novo
> contrato de método. Base: S1–S4 e S6 do registro de fontes de 18/10/2026 (Anexo 10).
> Preferir as melhorias da edição revista do guia (S3) às passagens equivalentes de S2;
> tratar bibliografia e exemplos dos dois como literatura de trabalho.

## Conteúdo

1. Posição filosófica; 2. Percurso interpretativo; 3. Reflexividade;
4. Dossiê imagem–norma; 5. Interpretação e infraestrutura.

## 1. Explicitar a posição sem deduzi-la das ferramentas

Distinguir quatro perguntas. A existência material do objeto, a construção histórica
de seu sentido e as categorias escolhidas pela pesquisadora não são a mesma questão.

| Plano | Pergunta para a tese | Controle da resposta |
|---|---|---|
| Ontologia | Que espécie de objeto e de relação institucional se investiga? | Não assumir que toda imagem tem a mesma agência ou eficácia normativa. |
| Epistemologia | Por quais vestígios e operações se pode sustentar uma afirmação? | Delimitar o que a fonte permite conhecer e o que permanece indecidível. |
| Axiologia e posição | Como interesses, escolhas e acesso condicionam a investigação? | Registrar consequências concretas na seleção e na interpretação. |
| Metodologia e técnicas | Por que esse percurso responde à pergunta delimitada? | Ligar cada operação à afirmação possível, às alternativas e aos limites. |

Ao apresentar interpretativismo, construcionismo, realismo crítico ou abordagem crítica,
explicar diferenças relevantes e consequências para o problema. Não escolher por Ana
uma nova filiação filosófica nem tratar tabelas pedagógicas como combinações exclusivas
entre ontologia, epistemologia e método. A orientação histórica e interpretativa vigente
permite explicitar seus pressupostos sem reabrir decisões a cada tarefa.

Manter contagens e indicadores subordinados ao catálogo documentado e à leitura densa.
Uso de Python, escalas, tabelas ou um atlas digital não decide por si o paradigma da tese.
Não declarar métodos mistos apenas porque texto e números convivem. Não converter a
aposentadoria do composto neste projeto em afirmação de invalidade universal de índices.

## 2. Tornar o percurso interpretativo examinável

Partir de uma pergunta ou estranheza documental, formular explicações possíveis e
confrontá-las com vestígios e casos discrepantes. Voltar à descrição quando a evidência
contradizer a interpretação. Usar abdução, indução ou dedução apenas com a função
explicitada; esses nomes não dispensam fontes nem instituem um novo protocolo.

Na articulação Panofsky–Warburg, distinguir descrição, identificação convencional,
interpretação contextual e arranjo relacional. A montagem pode fazer rever uma leitura;
a associação espacial das imagens não demonstra transmissão histórica. Nomear as tensões
entre os procedimentos e consultar as obras antes de atribuir-lhes uma fórmula literal.

A suficiência do catálogo depende do problema, dos critérios, das buscas realizadas e
dos limites de acesso. Não declarar exaustividade, saturação ou representatividade porque
os escores deixaram de variar. Registrar cobertura, condições de busca e casos exemplares
selecionados; manter N aberto, com versões identificadas.

## 3. Registrar reflexividade sobre decisões

Quando a tarefa envolver escolha ou revisão, registrar brevemente:

- qual pergunta e qual versão dos materiais orientaram a leitura;
- por que o objeto entrou ou ficou fora da comparação;
- qual interpretação inicial mudou, por qual evidência ou objeção;
- quais explicações concorrentes persistem e qual busca poderia distingui-las;
- que limite de idioma, acesso, reprodução ou posição da intérprete afetou o resultado.

Usar nota existente ou texto de trabalho. Não exigir diário novo para toda operação.
Revisão por pares e segunda leitura ajudam a detectar ambiguidades; não equivalem a
concordância métrica nem certificam automaticamente a interpretação.

## 4. Construir o dossiê imagem–norma

Para uma alegação jurídico-histórica substantiva, identificar os dois conjuntos de
fontes e o nexo entre eles. O vínculo pode passar por encomenda, uso institucional,
circulação oficial ou contexto jurídico; não exigir que a figura apareça dentro da lei.

| Componente | Registrar quando disponível |
|---|---|
| Objeto visual | Item/exemplar, autoria, datas de criação/edição/uso, suporte, dimensões, inscrição, emissor, cota e imagem consultada. |
| Fonte jurídica ou institucional | Jurisdição, autoridade, título, espécie documental, edição/versão, data de vigência relevante, artigo/página e localização. |
| Nexo | Encomenda, programa, ato de emissão, uso, citação, circulação ou outra relação efetivamente documentada. |
| Alcance | Quem era alcançado, em que território e período, e quais condições ou exceções a afirmação exige. |
| Lacuna | O que falta para distinguir nexo histórico, mera contemporaneidade e aproximação analítica. |

Separar prescrição normativa, doutrina, interpretação administrativa/judicial e prática
social. Distinguir exclusão expressa, exclusão interpretativa e restrição de fato. Não
inferir direitos, capacidade ou sufrágio só do título de uma norma ou de uma alegoria.
Consultar o texto histórico pertinente: versão compilada, alteração posterior ou resumo
atual não substituem a redação e o contexto do período em discussão.

Apresentar o nexo como **documentado**, **contextual** ou **interpretativo proposto**, com
fonte e justificativa; esses rótulos são instrumentos de redação, não novos campos do
schema. Anterioridade permite perguntar sobre antecipação; não a comprova. Contemporaneidade
não demonstra contato. Contraste entre imagem e norma não comprova intenção de denúncia.

A expressão "reconhecimento sem reciprocidade" deve ser testada por caso, considerando
jurisdição, período, condição livre/escravizada, estado civil e outras categorias pertinentes.
Não formular uma relação quantitativa inversa entre visibilidade alegórica e direitos
sem desenho, observações e evidência adequados; os anexos não fornecem tal demonstração.

## 5. Articular interpretação e infraestrutura

Tratar metadados, OCR, descrições por modelo e correspondências sugeridas como trabalho
assistido que exige fonte ou inspeção apropriada. Registrar o que foi efetivamente visto.
Verificar schema, arquivo e hash pode atestar estrutura e integridade, sem validar a
interpretação histórica. Duas projeções do mesmo ledger não são fontes independentes.

Distinguir item, figura/personificação, exemplar, observação de codificação e subconjunto
analítico antes de contar. Declarar denominadores e ausências quando houver distribuições
separadas por indicador; não fabricar um escore global. Recuperar a versão do instrumento
aplicada à observação, que pode diferir da versão mencionada no documento mais recente.

Conservar separados estatuto no recorte e estado da evidência. Não importar os tiers dos
relatórios para o schema, criar campos paralelos ou promover candidatos automaticamente.
Um fac-símile adequado pode sustentar descrição visual; não instituir inspeção física
universal como requisito novo. Para atribuições que dependam do original, explicitar
precisamente o que a reprodução não permite verificar.
