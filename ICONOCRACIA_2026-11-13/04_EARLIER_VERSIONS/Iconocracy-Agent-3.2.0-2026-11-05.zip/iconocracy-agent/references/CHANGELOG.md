# Histórico de versões: iconocracy-agent

## v3.1 (2026-10-18)

Integração crítica dos oito anexos enviados por Ana, identificados por título e SHA-256
no Anexo 10. Decisões canônicas conferidas em `84b256ce49a30050c28e113cb1b28b11c2982053`;
sem recontagem de dados, recodificação, alteração do repositório da tese ou certificação
bibliográfica integral. Os originais anexados foram preservados.

- Acrescentados Anexos 8 (filosofia e mediação jurídica), 9 (comparação e vulnerabilidade)
  e 10 (fontes, precedências e divergências), com roteamento no núcleo.
- Explicitação do foco da tese Brasil 1822–1922 e da janela contratual do catálogo core
  1800–2000, sem adjudicar a divergência formal nem importar 1239–1975 dos guias.
- Separação entre pressupostos, operações e alcance; contagem não escolhe paradigma;
  imagem–norma, intenção e recepção passam por nexos e documentação próprios.
- Comparação entre imagens e literatura preserva unidades e estatutos; vulnerabilidade,
  lamento, racialização e sátira permanecem perguntas abertas a contraprovas.
- Montagem distingue transmissão, analogia e contraponto. Corrigida a exigência antiga
  de migração documentada para toda vizinhança; preservada a proveniência dos objetos.
- Materialidade, escala e lacunas explicitadas sem novos indicadores ou schema. Níveis
  de evidência separados de core/comparador/apêndice; nenhuma promoção por IIIF ou tiers.
- Tratamento de legado no Anexo 4 alinhado à remoção de 24/09 e verificação de 29/09;
  retirada a ambiguidade de `legacy_frozen` em dados ativos. Escala 0–3 preservada, sem
  conversão automática de 0–4 nem reintrodução de confiabilidade métrica como prova.
- Exemplo ICONOCODE deixa versão desconhecida como `null` e exige versão efetivamente
  aplicada antes da persistência, em vez de copiar automaticamente 2.2.1.
- Registro de afirmações e citações suspeitas dos anexos, incluindo Jane Eyre, cronologias,
  correlação visibilidade–capacidade e edições divergentes de Mondzain.
- Metadados de interface atualizados; política de invocação e ícones preservados.

## v3.0 (2026-10-14)

Reorientação pelo prompt de orientação de Ana (out. 2026; texto integral em
`references/prompt-orientacao-2026-10.md`) e pela leitura do repositório `iconocracy-corpus`
no commit `dc5363b` (2026-10-13). Iconclass conferido em iconclass.org em 2026-10-14.

### Conteúdo e método

- Papel de orientadora sênior e interlocutora crítica; decisões estabelecidas separadas de
  hipóteses em investigação; lista datada de divergências entre o prompt e o repositório.
- O rascunho TODO de "Estado do problema" deu lugar à formulação de Ana: hipótese do regime
  iconocrático como proposição a testar, com famílias de explicação concorrente (estas
  são formulação do agente e podem ser cortadas).
- Recorte volta ao núcleo por instrução de Ana: corpus core 1800–2000; fora dele, comparador
  ou apêndice, fora das contagens do core. Contagens continuam no repositório.
- `DEC-2026-07-29-APARATO-MINIMO` no núcleo; vedado propor kappa, alfa, teste-reteste, dupla
  codificação cega, dimensionalidade, consistência interna, índice agregado, análise
  fatorial ou clusterização como validação ou prova; sem congelamento, com versão e
  changelog.
- Score de endurecimento retirado de instruções e JSON (`DEC-2026-07-28-COMPOSTO`,
  `DEC-2026-09-24-REMOCAO-CAMPO`); inventário verbal sobre os 10 indicadores 0–3, com as
  âncoras do codebook-MASTER v2.2.1. O "aparato v1.1" virou o Anexo 4 (regimes, recusas,
  inventário verbal), com a tipologia de recusas incorporada.
- ICONOCODE ganhou nível 0 (dossiê documental), vocabulário da fonte e três planos
  (dispositivo, intenção, recepção).
- Iconclass: `48C514`, `44B11`, `44B62` e `44A3` tinham sentido errado na v2.0; tabela
  refeita com rótulos oficiais.
- Ausência distinguida em três tipos; "segunda rodada cega" saiu do roteamento de modelos.

### Editorial e operacional

- Anexos movidos para `references/`, lidos sob demanda: o `SKILL.md` carregado a cada uso
  caiu para cerca de 27 KB, abaixo do arquivo único da v2.0 (41,6 KB), o que realiza o
  "núcleo enxuto" proposto na v2.0. Texto inalterado da v2.0 foi copiado literalmente.
- T1 nomeado `CC-NNN` (hook do repositório); binário no Drive (ADR-001); duplicatas contra
  `records.jsonl` (ADR-006); campos de estatuto, identificador, direitos e data de evento.
- Anexo 6 alinhado ao `AGENTS.md` (release gate, ARGOS, ambiente sem conda); caminho macOS e
  ponteiro para `docs/MODEL_ROUTING.md` (inexistente) removidos; no MasterRecord,
  `confidence` passa ao nível de `iconocode`, como pede `iconocode-output.schema.json`.
- Perguntas só quando a resposta muda o resultado.

## v2.0 (2026-09-21): reestruturação modular

- Núcleo enxuto; modos em anexos consultados sob demanda.
- Hipótese reaberta (set. 2026) passa a ser o enunciado de partida. Regimes,
  indicadores e endurecimento saem do núcleo e viram "aparato v1.1 (provisório)"
  no Anexo 4, mantido para rastreabilidade das codificações.
- Parâmetros do corpus não são mais fixados aqui: remeter ao AGENTS.md vigente.
- RESEARCHCLAW removido (pipeline de ML, sem aderência à história do direito).
- Hierarquia de evidência trocada por critério historiográfico.
- DIR410346 arquivada (disciplina 2026.1 concluída em ago. 2026).
- "Defesa prevista: 2026" removido; campo `triggers` removido (não era lido).

## v1.1

Escala 0–3, quarto regime, verificação de imagem real.
