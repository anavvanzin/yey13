# Anexo 2. Modo ICONOCODE: análise visual

> Anexo especializado preservado da versão de outubro. Usar com o núcleo atual e
> `metodo-e-fontes.md`. As antigas remissões numeradas a divergências/regras pertencem
> àquela versão histórica: conferir o conflito atual antes de executar. Exemplos,
> números, comandos e ferramentas não são automaticamente fatos ou recursos atuais.

#### Conteúdo

Dossiê documental; três níveis de leitura; inventário verbal; JSON de trabalho;
passagem ao schema; nota Obsidian e comportamento.

#### Nível 0: dossiê documental

Antes de Panofsky, reúna o que a documentação permite dizer sobre o objeto, marcando cada
campo como documentado (com fonte), inferido (com a razão) ou desconhecido:

- autoria (desenhista, gravador, escultor, ateliê);
- datação do objeto e, se houver, do evento (iconoclasmo, intervenção, reuso);
- suporte, técnica e dimensões;
- encomenda e autoridade emissora;
- contexto institucional;
- circulação (área, tiragem, duração de emissão, lugar de exibição);
- público;
- usos e reusos;
- proveniência, identificador estável e direitos;
- denominação na fonte: como documento, legenda, inscrição, ato normativo ou catálogo
  nomeiam a figura.

Sem ao menos datação, suporte e autoridade emissora, a leitura iconológica fica
explicitamente provisória. Se houver nexo com lei, programa ou outro texto, reunir o
dossiê imagem–norma do Anexo 8. Separar a evidência da imagem, da inscrição, do poema e
da documentação externa, conferindo a associação material no exemplar consultado.
Registrar restrição do suporte, solução compositiva ou causa indeterminada em prosa;
essa distinção não cria indicadores, não muda âncoras e não prova intenção ou recepção.

#### Nível 1: pré-iconográfico (Panofsky)

Descrever o que é VISÍVEL sem interpretação:
- **Figuras:** número, gênero, postura, gesto, direção do olhar
- **Vestimenta:** tipo, nível de cobertura, clássica/moderna
- **Atributos físicos:** objetos segurados ou vestidos (espada, balança, barrete,
  coroa, escudo, fasces, tocha, livro, tábua)
- **Composição:** arranjo espacial, enquadramento, fundo, escala
- **Suporte material:** meio, dimensões, técnica, cor/monocromo
- **Texto inscrito:** qualquer texto visível na/ao redor da imagem

#### Nível 2: iconográfico (Panofsky + Iconclass)

Identificar o significado convencional, a partir do vocabulário da fonte:
- **Denominação na fonte:** registrada no nível 0; vem antes da categoria analítica.
- **Motivo alegórico:** qual alegoria? (Marianne, Britannia, Germania, Columbia etc.)
  Identificação conservadora: "figura feminina com balança" antes de "Justitia", se os
  atributos não bastam.
- **Iconclass:** notações conferidas no núcleo (`SKILL.md`, Vocabulário); fora delas, consultar
  iconclass.org e registrar o rótulo oficial.
- **Tradição iconográfica:** qual tradição visual cita? (romana, revolucionária,
  neoclássica, Art Nouveau etc.)
- **Pathosformel:** propor uma fórmula gestual com contexto e comparanda pertinentes;
  estar de pé/sentada, dinâmica/estática ou armada/pacífica não basta para demonstrá-la.
- **Comparanda:** precedentes ou paralelos visuais conhecidos

#### Nível 3: iconológico

Interpretar o que a imagem faz na constituição da autoridade, separando os planos:
- **Sentido do dispositivo:** que autoridade a imagem constitui, legitima, sacraliza ou
  contesta, para quem, em que suporte e circuito de circulação. É o plano que a tese
  reivindica.
- **Intenção dos agentes:** só com fonte (programa, edital, ata, correspondência, ato
  normativo); sem fonte, `null`.
- **Recepção:** só com fonte específica; sem fonte, `null`. Atributo visual não prova
  efeito social.
- **Corpo e gênero:** como o corpo feminino (ou sua ausência) é mobilizado.
- **Colonialidade do ver:** (se aplicável) como opera a dimensão racial.
- **Contraprova e explicações concorrentes:** quais das famílias listadas no núcleo ("O
  projeto") o caso admite, e o que as afasta ou não.
- **Limites da leitura:** o que a análise não pode afirmar sem fonte adicional.

#### Inventário verbal (codificação para o corpus)

Ao codificar ou recodificar item para o corpus, registre o inventário verbal sobre os 10
indicadores (escala, âncoras e regras no Anexo 4,
`references/anexo-4-regimes-recusas-inventario.md`). Em análise interpretativa avulsa, só se
Ana pedir. Em resumo:

- grau 0–3 por indicador, e uma frase justificativa para cada atributo marcado, dizendo
  onde o traço se vê;
- `null` para indicador não codificado; 0 só como ausência observada;
- nada de soma, média, contagem de atributos ou número único; o regime não se deriva dos
  indicadores (`regime_iconocratico` só com base suficiente de leitura e dossiê; senão,
  `null`);
- antes de graduar, confirmar que o objeto é imagem real (regra operacional 1).

#### Output JSON

Formato de trabalho do agente. A gravação no ledger segue `tools/schemas/`
(`master-record.schema.json`, que remete a `iconocode-output.schema.json`), o bloco
`purificacao` do codebook-MASTER (§15–16) e os scripts do repositório. Não emita
`purificacao_composto` nem `endurecimento_score`.

```json
{
  "id": "CC-NNN",
  "iconocode": {
    "nivel_0_dossie": {
      "autoria": {"valor": "", "estado": "documentado|inferido|desconhecido", "fonte": ""},
      "datacao_objeto": {"valor": "", "estado": "", "fonte": ""},
      "datacao_evento": null,
      "suporte": {"valor": "", "estado": "", "fonte": ""},
      "encomenda_autoridade_emissora": {"valor": "", "estado": "", "fonte": ""},
      "contexto_institucional": {"valor": "", "estado": "", "fonte": ""},
      "circulacao": {"valor": "", "estado": "", "fonte": ""},
      "publico": {"valor": "", "estado": "", "fonte": ""},
      "usos": {"valor": "", "estado": "", "fonte": ""},
      "proveniencia": {"identificador_acervo": "", "direitos": "", "fonte": ""},
      "denominacao_fonte": ""
    },
    "level_1": {
      "figuras": [],
      "vestimenta": "",
      "atributos": [],
      "composicao": "",
      "suporte": "",
      "texto_inscrito": ""
    },
    "level_2": {
      "motivo_alegorico": "",
      "iconclass": ["11M44", "31AA231"],
      "tradicao": "",
      "pathosformel": "",
      "comparanda": []
    },
    "level_3": {
      "sentido_do_dispositivo": "",
      "intencao_dos_agentes": null,
      "recepcao": null,
      "corpo_e_genero": "",
      "colonialidade_do_ver": "",
      "contraprova_e_alternativas": "",
      "limites_da_leitura": ""
    },
    "purificacao": null
  }
}
```

Quando houver codificação, `purificacao` recebe (valores ilustrativos; `null` = não
codificado):

```json
{
  "desincorporacao": 2,
  "rigidez_postural": 1,
  "dessexualizacao": 2,
  "uniformizacao_facial": null,
  "heraldizacao": 3,
  "enquadramento_arquitetonico": 0,
  "apagamento_narrativo": 2,
  "monocromatizacao": 3,
  "serialidade": 3,
  "inscricao_estatal": 3,
  "atributos_iconograficos": [
    "heraldizacao: figura reduzida a emblema no campo da moeda; justificativa: onde se vê e por que sustenta o grau"
  ],
  "regime_iconocratico": null,
  "codebook_version": null,
  "notes": ""
}
```

No exemplo, `codebook_version: null` significa versão ainda não identificada. Preencher
com a versão efetivamente aplicada antes de persistir a observação; não usar a data da
execução, a menção a 2.3.0 numa decisão ou a versão de um relatório como substituto.

Na passagem ao schema canônico: notações vão para `codes` (`scheme`: `iconclass`,
`getty_aat`, `tgn`, `ulan` ou `custom`; `code_role`: `depicts`, `attribute`, `context` ou
`style`); afirmações vão para `interpretation` (`claim_type`: `iconographic`,
`legal_context`, `dating`, `attribution` ou `postcolonial_marker`; `status`: `supported`,
`tentative` ou `gap`), com o registro em `validation.claim_ledger`. O schema não tem tipo
próprio para intenção nem para recepção: o plano se declara no texto do claim, com a fonte,
e essa lacuna fica para avaliação de Ana.

#### Enrichment Obsidian

Quando aplicado a uma nota existente do vault, acrescentar a análise sob
`## IconoCode Analysis`, preservando todo o conteúdo existente.

#### Comportamento

- Se não há imagem acessível, analisar pela descrição e marcar `#análise-textual`
- Comparar com itens conhecidos do corpus quando possível, respeitando o estatuto de cada
  um (core, comparador, apêndice)
- Sugerir vizinhanças possíveis para montagem (modo ZWISCHENRAUM)
- Sinalizar itens que desafiam a hipótese em curso: contraexemplos são valiosos
