# Método, fontes e reconciliação

Consultar antes de codificar, contar, alterar critérios ou escrever sobre metodologia.
Esta referência reúne regras e conflitos; os schemas e o codebook pertinentes continuam
necessários para a operação concreta. Revisão: 05/11/2026.

## Conteúdo

1. Bases e precedência
2. Escalas de recorte e arquitetura
3. Aparato mínimo e regimes
4. Indicadores, ausências e contagens
5. Autoridade dos campos e projeções
6. Conflitos documentais
7. Teoria, atribuição territorial e fontes
8. Fontes principais

## 1. Bases e precedência

Reconciliar a skill local 3.1.0-review.1, de 02/11, com os anexos pessoais anteriores e as
fontes atuais. Preservar a orientação crítica, a autoria de Ana e os três estratos da
pesquisa: **registro documental, filologia teórica e hipótese iconológica**. Não confundir
esses estratos com regimes, etapas de codificação ou estados catalográficos.

Para método, verificar decisões pertinentes e revisões explícitas. A data mais recente de
um relatório não revoga sozinha uma decisão anterior. Distinguir decisão metodológica,
síntese de projeto, schema operacional, código executável, observação de dados e hipótese
interpretativa. Pedidos atuais de Ana orientam a tarefa no escopo autorizado; dúvidas
substantivas continuam sendo decisões autorais, não efeitos colaterais da edição.

A consulta de 05/11 usou corpus main `69fde439fc6813dfabf25d49a68728ecaedc88c7` e site main
`14ff9d8de057d1d3e72d9e00c7bd3f46e01fd267`. Usar as referências fixadas abaixo para reproduzir
essa leitura, mas verificar a versão atual quando a tarefa exigir atualização. Não executar
uma migração porque esta skill descreve uma divergência.

## 2. Escalas de recorte e arquitetura

Manter separadas:

| Escala | Formulação documentada | Consequência operacional |
|---|---|---|
| Tese | Brasil, 1822–1922 | Identificar o núcleo argumentativo e justificar comparadores. |
| Atlas/projeto contínuo | Transnacional; arquitetura de objetos, fontes, conceitos e argumentos | Pode incluir a tese e outras investigações autorizadas. |
| Contrato do catálogo | Janela 1800–2000 e critérios de inclusão do METHOD_CONTRACT | Conferir aplicabilidade ao conjunto, decisões posteriores e coortes separadas. |
| MOC de 02/11 | Também descreve atlas transnacional 1800–2000 | É formulação arquitetural vigente no documento; não delimita sozinho todo dado publicado. |
| Acervo efetivamente publicado | Documento de fronteira e stats declaram 1239–2021 | Cobertura de um conjunto derivado identificado, não novo critério normativo universal. |
| Comparadores, genealogia e eventos | Podem exceder o recorte | Declarar função, data do objeto e data do ato, sem contaminar denominadores. |

O MOC propõe um **Atlas de Iconologia Jurídica e Laboratório de Experimentação Visual**,
um **Contra-Arquivo**, catálogo de dois eixos e constelações coexistentes. O eixo documental
liga Objeto/Imagem/Fonte/Iconclass; o eixo interpretativo liga Claim aprovado/Conceito.
O protocolo Norma–Imagem requer nexo explicitado entre artefato visual e documentação
jurídica. Arquitetura proposta, rota implementada e conteúdo aprovado são estados distintos.

Tratar Hystera → matriz industrial → matriz digital, FUNDIÇÃO e novos títulos de capítulos
como elaboração do MOC até verificação de seu estatuto e aprovação pertinente. Conferir
alegações etimológicas, médicas e jurídico-históricas nas fontes; o MOC não demonstra por
si causalidade entre discurso médico, incapacidade jurídica e fixidez alegórica.

## 3. Aparato mínimo e regimes

Manter o percurso **teoria → critério de inclusão → catálogo documentado → leitura densa
de casos exemplares → montagem → análise**. Admitir revisões justificadas e registradas;
não encenar todas as etapas em toda resposta.

O catálogo é seleção documentada, sujeita a vieses de coleta, conservação e digitalização.
Contagens descrevem essa seleção; não estimam prevalência histórica em população definida.
A suficiência da escolha de casos depende do problema, dos critérios, da documentação e
das contraprovas, não de um N predeterminado ou de saturação por escores.

Fundacional, Normativo e Militar são três regimes analíticos construídos por leitura
contextualizada. Contra-alegoria testa e fratura esse quadro; não é quarto estágio de uma
evolução necessária. O schema aceita quatro valores, incluindo `contra-alegoria`; preservar
compatibilidade técnica sem converter o enum em ontologia histórica. Recusa, substituição
e ausência documentada também não são sinônimos de contra-alegoria.

A existência de registros rotulados `militar` não resolve a antiga suspensão de conclusões
sobre esse regime quando faltava codificação. Verificar a qualidade documental e a leitura
efetiva, não apenas presença de um rótulo ou de uma linha no ledger.

## 4. Indicadores, ausências e contagens

O composto aposentado não volta como soma, média, densidade, cardinalidade de atributos ou
novo ranking. A decisão de 24/09, com verificação de 29/09, supera a conservação do campo
ativo que documentos de julho ainda prescreviam. Manter dez indicadores ordinais 0–3
separados, conforme âncoras efetivamente aplicáveis, e inventário verbal sustentado pela
imagem. Não gerar justificativas verbais a partir de valores numéricos.

Distinguir não codificado de ausência observada. `null` exprime desconhecimento no trabalho
de análise; persistência deve respeitar o schema e seu mecanismo de pendência. Se o schema
não aceitar a representação necessária, manter o candidato/observação em revisão, documentar
o conflito e não inserir zero para fazer a validação passar.

Antes de usar qualquer percentual, verificar:

- unidade: item, figura, exemplar, reprodução, observação, candidato ou caso analítico;
- fonte canônica e versão;
- critério de inclusão, filtro temporal/geográfico e tratamento de datas incertas;
- exclusões, valores ausentes, importações e duplicações;
- denominador específico e limites de representatividade.

O status de um script pode contar linhas sem conferir conteúdo. Em 05/11, `show_status`
de `code_purification.py` usa `done = len(coded)`, portanto inclui importações explicitamente
pendentes. Não chamar essa porcentagem de “corpus codificado” sem qualificação e auditoria.
Ver os números e a regra de contagem na referência datada do projeto.

N continua aberto. Versão identificada e rastreabilidade são exigíveis; congelamento não.
Notebook 01 é descritivo; notebooks 02–08 são exploratórios/diagnósticos internos conforme
decisões pertinentes. Confiabilidade métrica, clustering e índices não são prova da tese.
Essa limitação não proíbe um experimento computacional separado, com objetivo e avaliação
próprios, como LegalVision.

## 5. Autoridade dos campos e projeções

Seguir ADR-006, aceito em 12/08/2026:

- `data/processed/records.jsonl`: identidade, fontes, descrição, claims e os campos
  qualitativos canônicos pertinentes em `purificacao`.
- `data/processed/purification.jsonl`: observações e proveniência de codificação, incluindo
  codificador, data, rodada, instrumento e adjudicação quando disponíveis.
- Manifest e Drive: identidade e armazenamento do binário.
- Vault: espelho auxiliar/navegação. CSV, SQLite, dashboards, public export e bundles HF:
  derivados reconstruíveis.

Evidências são identificadas pelo par `(item_id, evidence_id)`. O modelo de dados admite
múltiplas observações por item; uma contagem atual de IDs únicos não extingue essa capacidade.
Importação qualitativa do vault não pode fabricar observação de codificação. Revisão e
promoção controladas são operações próprias; não escrever diretamente em campos canônicos
por conveniência de uma extração ou resposta de modelo.

Preservar flags de dúvida, lacuna e proveniência em transformações. Um export mais simples
não pode promover um claim `gap` a prosa afirmativa. Ao testar uma projeção, verificar
integridade semântica, e não apenas validade de JSON ou igualdade de tamanho.

## 6. Conflitos documentais

| Fonte ou estado | Conflito | Tratamento |
|---|---|---|
| METHOD_CONTRACT 31/07 | ~328/~279 e legado do composto | Contagens históricas; remoção de setembro prevalece para campos ativos. |
| Decisão 29/07 e schema | Enumeração inclui contra-alegoria | Três regimes analíticos; preservar quarto valor técnico sem criar estágio. |
| Codebook MASTER | v2.2.1 no frontmatter, v2.2.0 no título e linguagem antiga de freeze | Identificar instrumento efetivo antes de codificar; não resolver pelo nome do arquivo. |
| Relatos de v2.3.0 | Referências a patch/piloto sem validação integral nesta atualização | Conferir o arquivo e suas âncoras se a tarefa depender dele. |
| CLAUDE.md | Contagem 336 e indicação de campos qualitativos achatados na projeção | Contrastar com dados atuais e README/AGENTS: canônicos sob `purificacao`; projeção enxuta os omite. |
| MOC/contrato versus acervo | 1800–2000 versus cobertura 1239–2021 | Explicitar escala e não reclassificar automaticamente. |
| Makefile/metadados de tese | Título histórico dos séculos XIX–XX | Não converter metadado de build em decisão autoral atual. |
| N=145 | Antigo subconjunto analítico | Manter como snapshot; nunca denominador de percentuais atuais sem reconstrução. |

Questões antigas sobre suportes, nomes de notas, `docs/CODING_PROTOCOL.md` e termos de
outubro não foram todas revalidadas em 05/11. Tratá-las como itens históricos a conferir,
não anunciar automaticamente que continuam bloqueadas nem que foram resolvidas.

## 7. Teoria, atribuição territorial e fontes

Preservar conceitos de Ana, empréstimos teóricos e vocabulário das fontes como categorias
distintas. Contrato Sexual Visual, Feminilidade de Estado, Contrato Racial Visual e
Purificação Clássica constam como formulações autorais no histórico do projeto; não atribuir
esses nomes a Pateman ou Mondzain sem a distinção de elaboração proposta por Ana.
Não declarar ineditismo absoluto sem revisão bibliográfica adequada.

Para Mondzain e demais interlocutores, conferir obra, edição, idioma e passagem realmente
usados. A preferência histórica por uma edição de 2002 não autoriza converter datas e
paginação de 2005 mecanicamente. Não impor uma edição apenas porque um anexo antigo a cita.

A revisão de 02/11 registrou uso de “iconocracia” por Román Gubern em
[El síndrome de Eróstrato, 27/06/1985](https://elpais.com/diario/1985/06/27/internacional/488671203_850215.html).
Esse precedente lexical não estabelece cunhagem absoluta nem equivalência com Mondzain.
A passagem não foi novamente conferida nesta atualização; consultá-la antes de citação
literal ou de ampliar a afirmação. “Mnemosyne” remete a Warburg, sem obrigar a tese a mudar
de objeto para tornar-se estudo da memória.

Aplicar a correção expressa por Ana em 29/10: nacionalidade do artista, tema, produção,
emissão, circulação e guarda atual não determinam isoladamente o país de um objeto.
Nomear a relação territorial/jurisdicional sustentada pela fonte. Frequência por país não
demonstra transferência transatlântica. Cor de material não prova racialização; espada
não prova independência judicial; circulação alegada exige fonte de circulação.

## 8. Fontes principais

Todos os links abaixo fixam os documentos lidos na revisão de 05/11/2026:

- [Arquitetura Atlas e Tese, MOC de 02/11](https://github.com/anavvanzin/iconocracy-corpus/blob/69fde439fc6813dfabf25d49a68728ecaedc88c7/atlas/Arquitetura%20Atlas%20e%20Tese%20%E2%80%94%20MOC.md).
- [METHOD_CONTRACT de 31/07](https://github.com/anavvanzin/iconocracy-corpus/blob/69fde439fc6813dfabf25d49a68728ecaedc88c7/docs/METHOD_CONTRACT_2026-07-31.md).
- [Remoção definitiva do campo, setembro](https://github.com/anavvanzin/iconocracy-corpus/blob/69fde439fc6813dfabf25d49a68728ecaedc88c7/docs/decisions/2026-09-24-remocao-definitiva-do-campo.md).
- [ADR-006, autoridade dos campos e projeções](https://github.com/anavvanzin/iconocracy-corpus/blob/69fde439fc6813dfabf25d49a68728ecaedc88c7/docs/adr/006-canonical-field-ownership-and-projections.md).
- [Schema MasterRecord](https://github.com/anavvanzin/iconocracy-corpus/blob/69fde439fc6813dfabf25d49a68728ecaedc88c7/tools/schemas/master-record.schema.json).
- [Integração de contra-alegorias, 26/06](https://github.com/anavvanzin/iconocracy-corpus/blob/69fde439fc6813dfabf25d49a68728ecaedc88c7/docs/decisions/CONTRA-ALEGORIAS-INTEGRATION-2026-06-26.md).
- [Fronteira do acervo publicado](https://github.com/anavvanzin/iconocracia/blob/14ff9d8de057d1d3e72d9e00c7bd3f46e01fd267/docs/acervo-boundary.md).
- [Método de constelações](https://github.com/anavvanzin/iconocracia/blob/14ff9d8de057d1d3e72d9e00c7bd3f46e01fd267/docs/constellation-method.md).
- [Síntese CPLX/ICONOCRACIA usada na revisão de 02/11](https://docs.google.com/document/d/1mpkQKb0pvexRSJ-R7mjiXJrNgFUBMyW284WhebovVd8/edit), documento de trabalho, não confirmação independente de suas fontes.

As referências de outubro permanecem disponíveis como instrumentos e história de trabalho.
Não importar delas números, bibliografia, regras ou interpretações como fatos verificados
apenas porque foram preservadas na pasta da skill.
