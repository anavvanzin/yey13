# Protocolos de trabalho do Iconocracy Agent

Aplicar estes protocolos ao objetivo solicitado. Eles organizam o trabalho; não concedem
permissão para publicar, enviar mensagens, alterar decisões teóricas, modificar um corpus
canônico, instalar integrações ou consumir serviços pagos. Respeitar as autorizações atuais
e as regras do ambiente. Consultar o núcleo e os anexos especializados antes de executar.

## Conteúdo

1. Contrato de tarefa e ciclo de execução
2. Reconciliação de versões
3. Registro de afirmações e fontes
4. Busca brasileira e admissão no corpus
5. Revisão de artigo e resposta a parecer
6. Atlas, constelações e publicação
7. Apresentações e desenho visual
8. Pesquisa computacional adjacente
9. Critérios de conclusão

## 1. Contrato de tarefa e ciclo de execução

Começar pela entrega que Ana pediu, e não por um plano abrangente para todo o projeto.
Determinar, com o contexto disponível:

- objetivo e pergunta de pesquisa;
- objeto da entrega: tese, artigo, catálogo, atlas, apresentação ou experimento;
- escala e fronteira: países, datas, suportes e estatuto dos comparadores;
- arquivo ou fonte de partida, versão e destino;
- operações autorizadas e decisões que dependem de Ana;
- teste que permitirá declarar a entrega concluída.

Perguntar apenas pelo dado que realmente impede uma escolha segura. Uma preferência
opcional não deve interromper pesquisa independente já autorizada. Não inferir publicação
a partir de pedidos como pesquisar, melhorar, revisar ou preparar.

Executar o ciclo: **inspecionar → delimitar → escolher a próxima ação útil → executar →
verificar → registrar o resultado → entregar**. Repetir quando a verificação revelar uma
falha recuperável dentro do escopo. Se houver bloqueio, identificar operação, alvo,
motivo, parte concluída e decisão necessária. Não apresentar um plano como execução.

Manter a distinção entre preparado, executado, revisado, aprovado, enviado, publicado e
verificado em produção. Cada estado exige sua própria evidência. Não marcar como concluído
um objetivo cujo próximo passo indispensável continua pendente.

## 2. Reconciliação de versões

Localizar o material já produzido antes de criar uma nova cópia. Para artigos e tese,
comparar os repositórios pertinentes, o Drive e os arquivos entregues por Ana. Para sites,
comparar o branch de trabalho, PRs, main e produção. Nenhuma dessas superfícies substitui
automaticamente as demais.

Construir uma matriz pequena de versões quando houver conflito:

| Versão | Fonte e data | Conteúdo distintivo | Estatuto | Próxima verificação |
|---|---|---|---|---|
| Documento localizado | URL/caminho e versão | Alterações efetivamente lidas | Rascunho/revisado/aprovado/exportado | O que falta conferir |

Não escolher o mestre apenas por data de modificação, por nomes como FINAL/latest ou por
formatação mais polida. Preferir a versão expressamente escolhida por Ana; sem isso,
indicar a versão mais recente localizada e a razão para usá-la provisoriamente. Preservar
o original e as mudanças paralelas. Registrar quais passagens foram incorporadas,
conflitantes ou deliberadamente deixadas de fora.

Não transmitir erros de uma versão-fonte para um derivado que já os havia corrigido.
Revisão de manuscrito, revisão do roteiro, revisão das notas de slides e exportação são
operações distintas. Conferir a propagação de correções em todas as entregas solicitadas.

## 3. Registro de afirmações e fontes

Separar pelo menos cinco planos: **observação visual**, **metadado documental**,
**fundamentação teórica**, **interpretação de Ana** e **hipótese ainda aberta**.
Registrar para afirmações centrais:

| Afirmação | Plano | Fonte efetivamente consultada | Localizador | Limite/contraprova | Estado |
|---|---|---|---|---|---|
| Formulação precisa | Um dos cinco planos | Obra, edição, objeto ou registro | Página, artigo, cota ou seção | O que a fonte não prova | Verificada, parcial ou pendente |

Esses são rótulos de trabalho. Ao persistir dados, usar o schema vigente, sem criar campos
ou vocabulários paralelos por conta própria. Não transformar o número de fontes em uma
escala universal de verdade: um registro institucional pode sustentar autoria catalogada,
mas não demonstrar circulação, intenção ou efeito social. Duas cópias da mesma informação
não constituem corroboração independente.

Distinguir acesso ao texto completo de resumo, OCR, snippet, referência bibliográfica e
relato de leitura anterior. Aspas e páginas pedem conferência no exemplar identificado.
Se a redação foi verificada mas a paginação veio de fonte indireta, conservar a diferença.
Não inventar uma página para completar ABNT. Não usar uma resposta de modelo como fonte.

Para relações entre imagens, classificar o nexo: transmissão documentada, relação
institucional, contemporaneidade, analogia formal ou montagem interpretativa. Uma sequência
cronológica não prova sucessão semântica. Semelhança não prova influência. O ato de vendar
uma figura e a venda como atributo iconográfico não são a mesma operação.

## 4. Busca brasileira e admissão no corpus

Quando o pedido for desenvolver o núcleo brasileiro da tese, iniciar por Brasil,
1822–1922, e pelos suportes pertinentes ao problema. Quando for ampliar o atlas ou revisar
o catálogo, declarar a fronteira própria em vez de aplicar silenciosamente a da tese.

Escolher acervos pela pergunta: Biblioteca Nacional/BNDigital e Hemeroteca, museus e
arquivos nacionais, registros do Senado e da Câmara, acervos monetários do Banco Central,
arquivos locais e instituições responsáveis pelo objeto. Esses são pontos de busca,
não garantias de disponibilidade ou direitos. Usar Firecrawl e ferramentas semelhantes
para descoberta e extração quando acessíveis; seus resultados não substituem a página
institucional nem a inspeção da imagem.

Para cada candidato:

1. Localizar registro e identificador estável; separar página de catálogo e arquivo visual.
2. Inspecionar a reprodução real, sua qualidade e sua correspondência ao registro.
3. Verificar autoria, encomenda/emissão, datas, suporte, instituição e direitos disponíveis.
4. Distinguir nacionalidade do artista, lugar de produção, autoridade emissora, território
   representado, circulação histórica e localização atual. Não condensar isso em “do país X”.
5. Comparar identidade de obra, exemplar, edição, variante, fotografia e cópia antes de
   deduplicar. Hash igual demonstra identidade do arquivo, não de toda a história do objeto.
6. Aplicar o critério de inclusão da escala declarada, conservando os estados candidato,
   comparador e admitido. A admissão exige a decisão e o fluxo vigentes.
7. Registrar o que falta e a próxima verificação possível. Nenhum direito não informado
   vira autorização de reprodução; nenhum resultado vazio de busca vira ausência histórica.

Entregar uma lista priorizada e documentada, com candidatos, exclusões justificadas,
duplicatas potenciais e lacunas. Não inflar o corpus com resultados de busca não examinados.

## 5. Revisão de artigo e resposta a parecer

Ler primeiro o artigo, o parecer/comentários e o cotejo já existente. Separar elogio,
correção factual, objeção de argumento, sugestão opcional e decisão autoral. Não repetir
uma auditoria concluída apenas porque há muitos comentários no arquivo original.

Usar uma matriz: comentário → trecho atual → tratamento já dado → pendência real → fonte
ou decisão necessária. Antes de polir, testar se o texto sustenta um argumento delimitado
de artigo ou promete um programa de pesquisa ainda não realizado. Propor cortes e
reordenações com seu custo argumentativo; Ana decide as mudanças substantivas.

Rever transições, repetição entre seções, escala dos exemplos, atribuições e páginas de
citações. Não converter exemplos europeus ou posteriores em prova do núcleo brasileiro.
Não descrever o campo brasileiro como demonstração concluída se o manuscrito o apresenta
como frente comparativa aberta.

Para resposta a orientador, verificar primeiro o que Ana já enviou. Agradecimento anterior
e resposta substantiva são estados diferentes. Preparar a resposta solicitada com mudanças
realizadas, escolhas abertas e perguntas delimitadas; não enviá-la sem autorização.

## 6. Atlas, constelações e publicação

Tratar catálogo, constelações, ensaios, conceitos, percursos e tese como camadas conectadas,
com estatutos próprios. Uma página metodológica do site comunica o projeto; não revoga
decisões registradas nem confere automaticamente autenticidade a um registro.

Mostrar em cada objeto: identidade documental, fonte, crédito, direitos quando conhecidos,
estado de verificação e papel no argumento. Mostrar em cada relação: a base documental ou
o estatuto interpretativo. Conservar divergências acessíveis, não escondidas pela interface.

Antes de exibir números, verificar fonte, unidade, versão, filtro e tratamento de
placeholders. Não reutilizar percentuais de demonstração, o N=145 histórico ou uma contagem
de fotografias como número de obras. Testar se componentes visuais realmente leem os dados
atuais; carregar um JSON sem ligá-lo à interface não transforma uma demo em resultado.

Separar teste de código, inspeção visual, revisão historiográfica, aprovação editorial e
implantação. Verificar versões móveis, teclado, contraste, foco, imagens, créditos, rotas e
fallback estático quando houver animação/WebGL. Preservar IDs, links e destinos impressos.
Uma mudança de nome público não autoriza renomear domínio, repositório, skill ou registros.

## 7. Apresentações e desenho visual

Preservar a criatividade visual de Ana. Rigor acadêmico não exige apresentação rígida,
paleta predefinida ou sequência repetida de título e bullets. Usar composição, ritmo,
escala, detalhes e justaposição para tornar o argumento visível, com leitura à distância,
acessibilidade e fallback estático.

Distinguir experimento gráfico de evidência histórica. Não alterar imagens para fabricar
atributos, inscrições ou relações. Identificar recortes e manter a composição completa
quando necessária ao argumento. Não substituir uma obra por outra silenciosamente.

Ler a fonte-base da intervenção e manter o gênero: uma fala como debatedora responde ao
texto do convidado; uma comunicação pode desenvolver argumento próprio. Mapear roteiro,
slides, notas, fontes, transições e tempo. Contar apenas texto falado, separando cortes
opcionais. Estimativa de duração não equivale a ensaio realizado. Versões EN/IT completas
são alternativas, não duas falas a somar no mesmo intervalo.

## 8. Pesquisa computacional adjacente

Manter LegalVision/Visão Computacional distinto da demonstração historiográfica da tese.
As restrições do aparato mínimo sobre prova da tese não proíbem métricas adequadas a um
experimento computacional separado, com desenho, dados e limitações próprios.

Separar entrada preparada, anotação humana, referência provisória, saída bruta do modelo,
validação de formato, correção semântica e interpretação dos resultados. Preservar saídas
que falharam; um parser reparador não pode substituir a resposta original e transformá-la
silenciosamente em acerto. Testes de software, hash e consistência do auditor não validam
pixels nem grounding. Uma resposta diferente com imagem não prova benefício geral.

Executar somente o experimento autorizado, com versão da fonte, modelo, configurações,
condições, entradas e saídas preservadas. Não tratar disponibilidade de créditos ou de um
modelo como autorização permanente de consumo, publicação ou acesso.

## 9. Critérios de conclusão

Entregar resultado e localização utilizável, fontes efetivamente consultadas, alterações
feitas, testes executados e lacunas materiais. Para arquivos, conferir integridade,
referências relativas e, quando cabível, renderização. Para uma atualização de skill,
verificar o artefato salvo; uma cópia de revisão não é instalação. Para publicação,
verificar o destino após a ação autorizada; build verde não comprova produção atualizada.

Terminar com o próximo passo concreto apenas quando ainda necessário. Evitar transformar
cada entrega em uma nova lista abrangente, ou reabrir decisões que o trabalho não exigiu.
