# Estado verificado do projeto em 05/11/2026

Usar como ponto de partida para reconciliação, nunca como garantia de que o estado permanece
igual. Reabrir os documentos pertinentes antes de executar trabalho posterior. Distinguir
inspeção de fonte, relato de execução anterior, decisão de Ana e próximo passo proposto.
Esta referência registra somente trabalho de pesquisa relacionado ao projeto.

## Conteúdo

1. Prioridades e nomes
2. Atlas, tese e arquitetura
3. Corpus e qualidade de codificação
4. Manuscrito e compilação
5. Proveniência de imagens e publicação
6. O contrato visual e Georges
7. Apresentações de novembro
8. LegalVision e Visão Computacional
9. Limites desta atualização

## 1. Prioridades e nomes

Em 05/11, Ana pediu que **O contrato visual e a resposta substantiva a Georges** fossem
tratados como prioridade junto das apresentações de novembro. Não estabeleceu uma ordem
fixa entre eles. Manter a prioridade no trabalho pertinente sem converter esta fotografia
de estado em agenda permanente.

Em 02/11, Ana considerou renomear projeto e tese para **Mnemosyne Viva**, mas depois pediu
pesquisa extensa antes da decisão. A identidade pública e o título formal continuam
separáveis. Preservar os nomes existentes até decisão específica, inclusive URLs, IDs e
títulos históricos. Iuris Memoria foi alternativa discutida; os títulos Do Mármore à
Margem, Muta Imago e Lex Hysteria aparecem no MOC como propostas provisórias.

O uso de nomes em protótipos, marcadores impressos, cabeçalhos e README não resolve sozinho
a decisão geral. Não renomear esta skill, domínios ou repositórios como efeito colateral.

## 2. Atlas, tese e arquitetura

Fonte primária de projeto: [MOC de 02/11](https://github.com/anavvanzin/iconocracy-corpus/blob/69fde439fc6813dfabf25d49a68728ecaedc88c7/atlas/Arquitetura%20Atlas%20e%20Tese%20%E2%80%94%20MOC.md).
Corpus main consultado: `69fde439fc6813dfabf25d49a68728ecaedc88c7`, de 02/11, 22:38 UTC.

O MOC explicita o atlas transnacional como projeto contínuo e laboratório visual, com a
tese **Brasil, 1822–1922** como eixo identificado. Registra catálogo de dois eixos,
Contra-Arquivo, constelações coexistentes, protocolo Norma–Imagem e experimentação visual.
As cinco superfícies, quatro capítulos híbridos, CMB-AUD-01..07 e FUNDIÇÃO são declarações
de arquitetura no documento; sua existência no MOC não comprova implementação ou aprovação
de cada conteúdo. O experimento não deve ser confundido com uma conclusão da pesquisa.

A arquitetura usa 1800–2000 como horizonte transnacional. O contrato do catálogo também
registra essa janela. A [fronteira publicada](https://github.com/anavvanzin/iconocracia/blob/14ff9d8de057d1d3e72d9e00c7bd3f46e01fd267/docs/acervo-boundary.md)
e o [stats.json atual de main](https://github.com/anavvanzin/iconocracia/blob/14ff9d8de057d1d3e72d9e00c7bd3f46e01fd267/site/data/stats.json)
declaram cobertura 1239–2021, 337 itens, 332 com imagem, 17 países e subconjunto brasileiro
1822–1922 de 53 itens. Esses valores foram lidos no derivado; datas, países, imagens e
elegibilidade não foram integralmente recontados item a item nesta atualização.

Consequência: conservar separadas a janela contratual, a arquitetura, a cobertura efetiva
e o recorte da tese. Não reduzir ou ampliar silenciosamente o core para fazê-los coincidir.

## 3. Corpus e qualidade de codificação

Inspeção integral e parsing dos dois ledgers no commit fixado acima:

| Arquivo/unidade | Resultado em 05/11 | O que não demonstra |
|---|---|---|
| records.jsonl | 337 registros | 337 casos verificados ou imagens aprovadas. |
| purification.jsonl | 286 linhas, 286 IDs distintos | 286 codificações substantivas válidas. |
| Inventário verbal em records | 22 registros com `purificacao.atributos_iconograficos` não vazio | Completude ou qualidade de todas as justificativas. |
| Inventário no ledger purification | Nenhuma chave `atributos_iconograficos` | Ausência dos inventários em outras fontes. |
| Campos agregados | Zero ocorrências de `endurecimento_score` e `purificacao_composto` nos dois ledgers | Ausência em todos os documentos históricos/derivados. |

Fontes: [records.jsonl](https://github.com/anavvanzin/iconocracy-corpus/blob/69fde439fc6813dfabf25d49a68728ecaedc88c7/data/processed/records.jsonl),
blob `8873fd4fda8bfb00686ea8a7cf63bb3da0a8fa08`; [purification.jsonl](https://github.com/anavvanzin/iconocracy-corpus/blob/69fde439fc6813dfabf25d49a68728ecaedc88c7/data/processed/purification.jsonl),
blob `f2546abedb3274b6486e59ac00dbeb3956db8dd6`.

**Zero-vetores:** a regra inspecionada exige todos os dez indicadores exatamente zero
numérico. Há 77 linhas assim:

- 57 `vault-import`, todas com “Codificação pendente — importado do vault”;
- 19 `migration`, de 04/04/2026, sem notas explicativas de observação;
- uma de `ana`, SCOUT-571, de 23/06, com nota substantiva sobre contra-alegoria feminina
  indígena que substitui Colombo.

Não tratar os 77 como ausências observadas válidas nem como um lote homogêneo a apagar.
Há 57 explicitamente pendentes, 19 migrados que requerem revisão de evidência e um vetor
autorado que pede exame próprio. A promoção ou correção de qualquer registro depende do
fluxo autorizado. ADR-006 exige observação e proveniência para um all-zero genuíno.

`code_purification.py`, função `show_status`, conta `done = len(coded)`. Seu total de
progresso inclui essas linhas pendentes e não basta para anunciar percentual de codificação.
O ledger contém 28 rótulos militares; esse total tampouco resolve qualidade ou sustentação
das conclusões sobre o regime. Não foram executados schemas, testes ou revisão visual do
corpus nesta atualização. Leitura/contagem de arquivos e validação científica são distintas.

## 4. Manuscrito e compilação

O [commit de 24/10, b1333ea](https://github.com/anavvanzin/iconocracy-corpus/commit/b1333ea46fe26c4c9671c74790dbffed5ce22c23)
removeu do capítulo 4 tabelas, valores e deltas derivados do composto, preservando indicadores
separados e discussão qualitativa. O capítulo 6 passou a identificar N=145 como snapshot
histórico, sem usá-lo como denominador atual de §6.1. O commit relata builds e 492 testes;
esse é um resultado histórico, não uma execução realizada em 05/11.

Fontes canônicas do manuscrito: `tese/manuscrito/`; capítulos do vault são espelhos.
O [Makefile efetivo](https://github.com/anavvanzin/iconocracy-corpus/blob/69fde439fc6813dfabf25d49a68728ecaedc88c7/vault/tese/Makefile)
está em `vault/tese/Makefile`, blob `c6071b184e7c772d7f849c43f233ab70f83bb874`.

Comandos conferidos no arquivo, não executados nesta atualização:

```sh
make -C vault/tese docx
make -C vault/tese pdf
make -C vault/tese capitulo-4.docx
make -C vault/tese capitulo-4.pdf
```

O alvo padrão é DOCX. O build integral lê Introducao_rev, capítulos 1–9 e Conclusao do
manuscrito. Produz `vault/tese/output/tese_completa.docx|pdf`, com cópia em
`tese/tese_completa.docx|pdf`; capítulos individuais ficam no output. `vault/tese/references.bib`
é obrigatório. PDF usa LuaLaTeX/TeX Gyre Termes por padrão, com overrides explícitos.
Não há `--number-sections`: a numeração editorial vem das fontes.

O metadado de título do Makefile ainda é histórico. Regenerar e conferir os exports após
edição; o fato de existir `tese_completa.docx` não demonstra que contém as últimas mudanças.

## 5. Proveniência de imagens e publicação

Site main consultado: `14ff9d8de057d1d3e72d9e00c7bd3f46e01fd267`, de 01/11.
O [README](https://github.com/anavvanzin/iconocracia/blob/14ff9d8de057d1d3e72d9e00c7bd3f46e01fd267/README.md)
descreve site estático/Cloudflare Worker, percurso aprovado **Columbia — dois chamados da
nação**, e `constituicoes-atlanticas`/lote de oito obras em revisão. Manifesto editorial
fora de `site/`; conteúdo review/withheld não vira preview público automaticamente.

A publicação requer aprovação autoral pertinente, crédito, evidência de direitos, alt text
e imagem local vinculada por hash. Aprovação de análise e aprovação de reprodução são
distintas. Layout determinístico por ID serve à navegação; não mede relevância científica
nem prova relação histórica entre objetos.

**Correções já integradas:** [Germania, 3725c6b, 24/10](https://github.com/anavvanzin/iconocracy-corpus/commit/3725c6b0e730ca409113e1d941182b956472a558)
corrige DE-100M-1908 para Germania em medalhão sustentado por indústria/agricultura, em vez
de Germania sentada. Distingue data impressa 07/02/1908 e reimpressões de selo verde de
1918–1922; desenho de Paul Thumann e gravura de Hans Meyer. Fabricação do exemplar e guarda
atual continuam sem verificação. A correção de metadados não recodificou o vetor herdado
`migration`, ainda todo zero.

**Correções em branch, sem publicação comprovada:** [PR83](https://github.com/anavvanzin/iconocracia/pull/83)
estava aberto, draft e sem merge, atualizado em 05/11 às 02:55:44 UTC. Head
`9f9144b90e01ef54bcc6e7cdef54416548c4c9ce`, branch `fix/atlas-launch-reconcile-20261102`.
O diff confirma:

- BE-002: thumbnail corrigido e distinção entre arquitetura em domínio público e fotografia
  de Fred Romero (2015), CC BY 2.0, com crédito/fonte;
- BR-005: thumbnail e crédito corrigidos, com divergência explícita. A imagem exibida
  corresponde visualmente ao *Retrato da República* do Senado (1919); o registro NYU/MHN
  descreve esboço c.1900, 97 × 77 cm. Metadados originais preservados, sem adjudicação;
- auditoria de 04/11: origem Commons de UK-004 removida/404, mas WebP local ainda disponível.
  Substituição/aviso não implementados, pendentes de decisão autoral. Disponibilidade local
  não comprova direito de uso.

Fontes: [auditoria BE-002/BR-005](https://github.com/anavvanzin/iconocracia/blob/9f9144b90e01ef54bcc6e7cdef54416548c4c9ce/docs/auditoria-be-002-br-005.md)
e [créditos de reprodução, 04/11](https://github.com/anavvanzin/iconocracia/blob/9f9144b90e01ef54bcc6e7cdef54416548c4c9ce/docs/auditoria-creditos-reproducao-2026-11-04.md).
São inspeções de branch; não equivalem a revisão binária/visual de todas as imagens nem
certificam o estado servido por iconocracia.com. Nenhuma publicação foi feita por esta atualização.

## 6. O contrato visual e Georges

Georges escreveu em 24/10 que *O contrato visual* parecia “quase pronto para publicação”,
tratando muitas notas como pontos de discussão. A avaliação menos favorável referia-se a
*Maria, Marianne e a República*, outro texto. Ana respondeu no mesmo dia agradecendo.
As buscas de e-mail conferidas em 05/11 não localizaram resposta substantiva posterior
nem envio de versão revisada; isso não exclui comunicação em outro canal.

O [cotejo das 44 anotações](https://docs.google.com/document/d/1gBslX-LwIMPjz5gQSffdriP815ntQf8zg73_aq2sby0/edit)
já distingue correções, elogios, sugestões opcionais e decisões, com 16 intervenções únicas.
A [revisão documental de 02/11](https://docs.google.com/document/d/1ql3jbExlontZsN68Dnh1wNIDj4MxCvNhldY-Nsd93PI/edit)
é a versão mais recente localizada, não uma versão final autoral certificada. Contém
fotografias históricas de Berna, distinção original/cópia, Ripa 1603 pp. 187–189 e retirada
da sucessão semântica afirmada entre exemplos. A presença dessas mudanças foi verificada
no documento; suas fontes externas não foram todas reabertas nesta atualização.

Pendências úteis para uma revisão focada:

1. GM-35: o artigo sustenta argumento delimitado ou ainda promete um programa de pesquisa?
2. GM-27/28: integrar melhor a transição para raça e Brasil.
3. GM-41: verificar repetição do Brasil entre §§7.3–7.4.
4. Conferir localizadores das afirmações teóricas decisivas e a coerência dos exemplos.
5. Preparar, quando solicitado, resposta substantiva a Georges com mudanças e perguntas.

Não refazer as 44 notas por padrão, nem usar os exports ABNT de 30/10 como mestre sem
reconciliação: foram identificados como incompletamente consolidados. O próximo passo deve
partir do manuscrito recente, do cotejo e das decisões de Ana.

Fontes da correspondência verificadas: [mensagem de Georges, 24/10](https://outlook.live.com/owa/?ItemID=AQMkADAwATdiZmYAZC04NDQAZi1jNzRlLTAwAi0wMAoARgAAA7jDcMXLZ55An3RbL%2FtjTUcHAJ9j8%2BIHkNRAr0oJ9VNHsuoAAAIBDAAAAJ9j8%2BIHkNRAr0oJ9VNHsuoACYTv5HUAAAA%3D&exvsurl=1&viewmodel=ReadMessageItem)
e [resposta de Ana](https://outlook.live.com/owa/?ItemID=AQMkADAwATdiZmYAZC04NDQAZi1jNzRlLTAwAi0wMAoARgAAA7jDcMXLZ55An3RbL%2FtjTUcHAJ9j8%2BIHkNRAr0oJ9VNHsuoAAAIBCQAAAJ9j8%2BIHkNRAr0oJ9VNHsuoACYTwE5AAAAA%3D&exvsurl=1&viewmodel=ReadMessageItem).
Status de trabalho: [cartão existente](https://trello.com/c/L4G6gQFX). Ler a descrição e o
histórico, pois a marca antiga de conclusão foi relatada como incoerente com “Sua revisão”.

## 7. Apresentações de novembro

### 11/11: resposta a Dauchy

Intervenção em inglês, dez minutos; sessão de Montesquieu às 15h10. O gênero é discussão
do [texto de Serge Dauchy](https://docs.google.com/document/d/1B37Fuj4wKxMJaQU06BrfTQiEy3XfCnl7/edit),
não palestra autônoma sobre toda a tese. Focar liberdade em contexto, recepção/transplantes,
quatro poderes em 1824 e pergunta de Dauchy sobre o Código Civil de 1916. Não inventar
influência direta de Montesquieu em Beviláqua.

Existem [sete slides corrigidos](https://chatgpt.com/space/page_90e4513a4254819181dbc24bb2c87a6c)
e roteiro Dauchy-centred de 02/11, com 1.057 palavras declaradas. A pintura do compromisso
constitucional e a Justiça do STF são exemplos de apoio; o cartão eleitoral e a excursão
de 1969 foram retirados do argumento principal. Espada pode suscitar pergunta sobre
autonomia, sem provar independência judicial por si.

A versão criativa encontrada ainda conservava material antigo. Em 05/11 Ana confirmou
ter iniciado uma execução Codex, mas o resultado ainda não tinha sido conferido na conversa.
Não duplicar esse trabalho nem declarar a reconciliação pronta sem inspecionar a saída.
Preservar o desenho inventivo e atualizar sua estrutura com o argumento corrigido.
Estimativas e tabelas de tempo não substituem ensaio em voz alta.

Materiais: [pasta Montesquieu](https://drive.google.com/drive/folders/1Gj19UEm7TJtV-xyG6kwpriSZdoLR-hvw),
[fontes](https://drive.google.com/drive/folders/1Dizm5txTykK3wye0ppz4WsMUzUyMPIck),
[imagens](https://drive.google.com/drive/folders/1_ETQWp4YLykSVVdHQ2Cwy8E80JplodJR).

### 13/11: O contrato visual

Comunicação de 15 minutos, com roteiros completos alternativos em inglês e italiano e
plano de nove slides. Sessão às 14h; horário individual não confirmado. Conferir o deck
final, a imagem brasileira e o ensaio antes de marcar conclusão.

A auditoria preparatória de 04/11 confrontou os roteiros com a revisão de 02/11 e indicou:

- retirar afirmações de novidade absoluta que o próprio artigo não sustenta;
- distinguir decretos sobre bandeiras/armas/selos de oficialização de uma alegoria feminina;
- evitar “every pocket, every day” sem documentação de circulação;
- apresentar o Brasil como frente comparativa aberta quando esse for o estatuto no artigo;
- distinguir ato de vendar e venda como atributo, sem sucessão semântica universal;
- atribuir o paradoxo do consentimento à obra correta de Pateman, conferindo páginas;
- verificar objeto/versão de Villares e moeda efetivamente usados, não apenas metadados
  de Wikidata ou nome de arquivo Commons;
- não deduzir situação jurídica de todas as mulheres de uma imagem ou de um binário temporal.

São pontos de revisão documental, não confirmação externa integral de todas as fontes.
Ler o manuscrito e os materiais atuais antes de aplicá-los.

## 8. LegalVision e Visão Computacional

Trabalho adjacente de INE410159, Grupo 26, com Guilherme Trajano. Não confundir seus testes
com validação do argumento historiográfico da tese.

Fontes de trabalho: [repositório da dupla](https://github.com/GuiT2002/comma2026-multimodal-argumentation)
e [demonstração LegalVision](https://huggingface.co/spaces/warholana/legalvision).
Pacote de revisão humana de 02/11: seis casos ADD01–ADD06, doze entradas neutras preparadas
com/sem imagem, fichas separadas para revisão independente e adjudicação humana posterior.
Os HTMLs são material de consulta/impressão e **não salvam respostas**; as anotações são
registradas separadamente. Os estados iniciais são `not_reviewed` e conclusões `null`.

O arquivo `verification/tests.json` do pacote registra 59 testes de software aprovados:
38 auditoria/revisão, 14 integração, quatro adapter e três verificação do pacote. Registra
zero execuções de modelos **naquela preparação**. Contagem de testes não é acurácia nem
prova de compreensão dos pixels. O auditor verifica consistência formal; uma referência
semanticamente errada pode passar se estiver estruturalmente consistente.

O relatório entregue de **04/11, ADD04 paired smoke test**, fonte
`3f01dc7d1cbed59e26b5494772368200eea884c1`, documenta um par real com Gemma 4 E4B: sem imagem,
abstenção dentro de JSON; com imagem, interpretação também encapsulada em JSON. As duas
respostas falharam o formato de topo exigido. Foram preservadas sem reparo/substituição.
Uma repetição, ordem fixa sem imagem → com imagem, temperatura 0, top_p 1, máximo 256 tokens.

Esse teste verifica o caminho de execução multimodal, não acurácia, grounding ou benefício
causal/generalizável. Referências permanecem `assistant_proposed_pending_human_review`;
métricas de desempenho continuam não medidas. Não repetir o antigo “zero execuções” como
estado global, nem contar esse par como piloto completo dos seis casos.

Ana já enviara atualização substancial a Guilherme em 27/10. A novidade posterior é o pacote
independente de revisão e o par exploratório, não a existência inicial dos seis casos.
Antes de redigir outro contato, conferir correspondência e o canal usado; não enviar sem
autorização. A combinação da apresentação de 02/12 exige verificação atual com a dupla.

Próximo passo técnico: revisão humana dos casos/referências e decisão explícita sobre
aderência estrita de formato antes de ampliar os experimentos. Não inferir autorização
de chamadas pagas, compartilhamento ou infraestrutura a partir da disponibilidade de modelos.

## 9. Limites desta atualização

- Foram confrontadas fontes de projeto, arquivos e relatos de trabalho identificados,
  preservando distinção entre fonte primária, síntese e execução histórica.
- Não foram recodificados registros, adjudicadas atribuições, reexecutados testes do corpus,
  reabertas todas as fontes bibliográficas ou auditadas todas as imagens.
- Não foram enviados artigos, respostas, mensagens nem publicações externas por esta tarefa.
- Nenhum nome proposto foi adotado como definitivo. Nenhuma alteração de schema ou método
  foi aprovada implicitamente pela atualização da skill.
- Para uma futura ação, revalidar os fatos que podem mudar, sobretudo versões de manuscritos,
  aprovação autoral, estado de PR/deploy, direitos e resultados de experimentos.
