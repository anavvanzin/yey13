# Anexo 1. Modo SCOUT: busca em acervos

> Anexo especializado preservado da versão de outubro. Usar com o núcleo atual e
> `metodo-e-fontes.md`. As antigas remissões numeradas a divergências/regras pertencem
> àquela versão histórica: conferir o conflito atual antes de executar. Exemplos,
> números, comandos e ferramentas não são automaticamente fatos ou recursos atuais.

> Para campanhas extensas, prefira a skill `corpus-scout`. Critérios de inclusão: o
> METHOD_CONTRACT vigente; recorte, suportes e estatutos (core, comparador, apêndice): o
> núcleo desta skill.

#### Protocolo de busca (adaptar à pergunta e às ferramentas disponíveis)

1. **Gallica MCP**, quando disponível: para buscas BnF/Gallica (IIIF). Para núcleo brasileiro, priorizar acervos brasileiros pertinentes antes de comparadores.
   - SRU: `dc.subject all "allegorie" and dc.subject all "Republique" and dc.date within "1880 1920"`
2. **Hugging Face Hub**: para papers acadêmicos, datasets e spaces relacionados
3. **WebSearch**: para portais de acervos (Europeana, Library of Congress, British Museum,
   BNDigital, Brasiliana Fotográfica, Numista, Colnect)
4. **WebFetch**: para verificar URLs e extrair metadados

#### Queries por acervo

| Acervo | Padrão de query | IIIF |
|--------|----------------|------|
| **Gallica / BnF** | `dc.subject all "allegorie" and dc.date within "YYYY YYYY"` | Sim |
| **Europeana** | `what:allegory AND what:justice AND when:[1880 TO 1920]` | Parcial |
| **Library of Congress** | `subject:"allegories"+"Columbia"+"justice"` | Parcial |
| **British Museum** | `q=britannia+allegory&object_type=print` | Não |
| **BNDigital** | `Republica + alegoria + monumento` | Não |
| **Brasiliana Fotográfica** | `brasilianafotografica.bn.gov.br` | Não |
| **Numista** | `numista.com/catalogue/` + país + período + motivo | N/A |
| **Colnect** | `colnect.com/stamps/` + país + período | N/A |
| **HF Hub** | `paper_search("female allegory iconography")` | N/A |

#### Escopo de busca

Ir **além das fachadas**. Arquitetura forense inclui decoração interior: murais de
tribunal, vitrais (Gerichtsvitrals), relevos de vestíbulo, pinturas de teto,
supraportas. Para moedas e selos, considerar variantes metropolitanas E coloniais.

Definir o conjunto antes da busca: Brasil 1822–1922 para o núcleo da tese;
janela contratual aplicável para o catálogo; arquitetura/seleção declarada para o atlas.
O contrato 1800–2000 não é limite universal de toda investigação. Externos à seleção
ficam como comparadores ou apêndices identificados. Em iconoclasmo, intervenção ou reuso, registre a data do objeto e a do
evento (divergência 4). Antes de abrir frente nova (país, suporte, cronologia), estime o
custo analítico e proponha corte.

#### Regras críticas

- **NUNCA inventar URLs.** Se não verificável, escrever `null` e adicionar `#verificar`
- **VERIFICAR QUE A URL RETORNA IMAGEM REAL.** Confirmar Content-Type de imagem
  (`image/jpeg`, `image/png` etc.). Páginas HTML de catálogo e PDFs salvos como `.jpg`
  são não-imagens e jamais devem ser codificados. Achado do IRR-PILOTO (2026-05-30):
  o relatório histórico registrou 38% do store como HTML/PDF mascarados (não é percentual atual), sobretudo de **fontes numismáticas
  (Numista/Colnect)**; nessas fontes, resolver a URL da imagem do espécime, não a
  página de catálogo. Não-imagem → todos os campos visuais = `null` + `#verificar-imagem`.
- Priorizar acervos com **IIIF** e com identificador estável (cota, inventário, ARK, PID):
  garantem rastreabilidade
- Transcrever direitos e identificador do registro do acervo; não inferir
- Se a ambiguidade da query mudar o que se busca, **perguntar antes de executar**; senão,
  declarar a leitura adotada
- Se encontrar mais de **8 candidatos**, priorizar por confiança e avisar
- **Checar duplicatas** contra `data/processed/records.jsonl` e `vault/candidatos/` antes de
  adicionar (`corpus/corpus-data.json` é projeção)
- Registrar lacunas pelo tipo de ausência: `#lacuna-coleta`, `#indisponivel-documental` ou,
  só com fonte, `#ausencia-alegorica`
- **Sugerir próximas buscas** ao final de cada sessão

#### Integração Hugging Face

- `paper_search`: papers sobre iconografia, DH, numismática
- `hub_repo_search`: datasets com tags: iconography, art-history, cultural-heritage
- `space_search`: spaces de classificação visual, CLIP, similaridade
- `hf_hub_query`: checar estado de `warholana/iconocracy-corpus`

#### Output

Gerar notas Obsidian atômicas conforme os templates abaixo (T2, nota Zwischenraum, fica
no Anexo 3, `references/anexo-3-zwischenraum.md`):
1. **Notas candidato** (`tipo: corpus-candidato`)
2. **Notas Zwischenraum** (`tipo: corpus-zwischenraum`)
3. **Notas de sessão** (`tipo: sessao-scout`)

### Ferramentas disponíveis

| Ferramenta | Uso |
|-----------|------|
| **Gallica MCP** | `gallica_search`, `gallica_search_iconography`, `gallica_get_metadata`, `gallica_get_iiif_manifest`, `gallica_get_image_url`, `gallica_get_image_info` |
| **HF Hub MCP** | `paper_search`, `hub_repo_search`, `hub_repo_details`, `space_search`, `hf_hub_query` |
| **WebSearch** | Buscas gerais em portais de acervos |
| **WebFetch** | Verificação de URLs, extração de metadados |
| **Notion MCP** | `notion-search`, `notion-fetch`, `notion-update-page` (quando disponível) |
| **Bash** | Scripts Python do repo, compilação, validação |
| **File tools** | Criar/editar notas Obsidian no vault |

### Templates

#### T1. Nota Candidato (`corpus-candidato`)

Arquivo: `CC-NNN Título curto.md` em `vault/candidatos/`, em que CC é o código do país e
NNN o próximo número livre nesse país (padrão do METHOD_CONTRACT; o hook do repositório
bloqueia outros nomes nessa pasta). As notas `SCOUT-NNN` existentes são legado e
continuam válidas como registro; não criar novas (divergência 9).

Os campos novos da v3.0 (`estatuto`, `criterio_inclusao`, `justificativa_estatuto`,
`denominacao_fonte`, `identificador_acervo`, `direitos`, `data_evento`) servem à nota. Se
o schema ou o `vault_sync.py` não os previrem, mantenha-os na nota e avise Ana, sem editar
schema. Identificador e direitos se transcrevem do registro do acervo; no ledger, campos de
proveniência são escritos por script.

```markdown
---
id: CC-NNN
tipo: corpus-candidato
status: candidato
estatuto: core  # core | comparador | apendice
criterio_inclusao: "METHOD_CONTRACT_AAAA-MM-DD"  # versão aplicada
justificativa_estatuto: null  # obrigatória para comparador, apêndice ou exceção ao recorte
titulo: "Título completo da obra"
denominacao_fonte: "Como o acervo, a legenda ou o ato nomeiam a figura"
acervo: "Nome do acervo/coleção"
identificador_acervo: "cota, nº de inventário, ARK ou PID; ou null"
direitos: "informação de direitos do registro do acervo; ou null"
url: "https://... ou null"
url_iiif: "https://... ou null"
data_estimada: "YYYY ou YYYY-YYYY"
data_evento: null  # iconoclasmo, intervenção, reuso
pais: [CC]
suporte: [tipo de suporte]
motivo_alegorico: "Nome da alegoria, ou descrição conservadora"
regime: null  # não atribuir na triagem; a tipologia se constrói por leitura densa
confianca: [alto|medio|baixo]
tags:
  - corpus/candidato
  - corpus/[core|comparador|apendice]
  - pais/[CC]
  - suporte/[tipo]
  - motivo/[motivo]
  - verificar
related:
  - "[[Conceito ou problema da tese]]"
  - "[[Item Relacionado]]"
hf_synced: false
data_scout: YYYY-MM-DD
---

## Identificação

**Título:** Título completo
**Denominação na fonte:** como a fonte nomeia a figura
**Acervo:** Nome do acervo
**Identificador estável:** cota, inventário, ARK ou PID (ou `null`)
**Direitos:** conforme o registro do acervo (ou `null`)
**URL de acesso:** [link](https://...) ou `null`
**URL IIIF:** [link](https://...) ou `null`
**Data estimada:** YYYY ou YYYY-YYYY (evento, se houver: YYYY)
**País:** [CC]
**Suporte:** Tipo de suporte
**Estatuto:** core | comparador | apêndice (com justificativa, se não for core)

---

## Análise preliminar

**Motivo alegórico:** Nome da alegoria (identificação conservadora: "figura feminina com
balança" antes de "Justitia", se os atributos não bastam)
**Critério de inclusão:** [como o item satisfaz cada um dos quatro critérios do
METHOD_CONTRACT vigente, ou qual deles falha]

**Atributos visíveis (descrição, sem grau):**
- [ ] balança
- [ ] espada
- [ ] venda nos olhos
- [ ] toga/vestimenta clássica
- [ ] fasces
- [ ] coroa mural
- [ ] escudo/brasão
- [ ] postura frontal
- [ ] contexto arquitetônico

**Contraprova ou explicação concorrente à vista:** [se houver]

---

## Rastreabilidade

**ABNT provisória:**
ACERVO. *Título*. Data. Suporte. Disponível em: URL. Acesso em: DD mês. YYYY.

**Binário:** Google Drive + `data/raw/drive-manifest.json` (no git, só metadado; ADR-001)
**Nota:** `vault/candidatos/CC-NNN Título curto.md`
**Ledger:** `data/processed/records.jsonl`, após ingestão por script

---

## Flags

- [ ] `#verificar`: confirmar data
- [ ] `#verificar`: confirmar autoria
- [ ] `#sem-iiif`: rastreabilidade comprometida (se aplicável)
- [ ] `#possivel-duplicata`: checar `records.jsonl` e `vault/candidatos/`
- [ ] `#fora-do-core`: comparador ou apêndice (se aplicável)

---

## Observações do Scout

[Contexto histórico, relação com outros itens, lacunas por tipo de ausência.]

### Referências HF

[Papers, datasets ou spaces encontrados via HF Hub. Tag: `#ref-hf`. Omitir se nenhum.]
```

#### T3. Nota de Sessão (`sessao-scout`)

Arquivo: `SCOUT-SESSION-YYYY-MM-DD.md` em `vault/sessoes/`

```markdown
---
id: SCOUT-SESSION-YYYY-MM-DD
tipo: sessao-scout
data: YYYY-MM-DD
query_executada: "Descrição da busca"
total_candidatos: N
pais: [CC, CC, ...]
periodo: "YYYY-YYYY"
tags:
  - corpus/sessao-scout
  - protocolo
related:
  - "[[DB1 Corpus Iconográfico]]"
  - "[[IconoCode -- Protocolo]]"
---

## Resumo da sessão

**Query:** [O que foi buscado]
**Acervos consultados:** [Lista]
**Candidatos encontrados:** N (core: N; comparador: N; apêndice: N)
**Nível de confiança predominante:** alto / médio / baixo

## Lacunas identificadas

[O que o catálogo ainda carece neste recorte, separando ausência de coleta,
indisponibilidade documental e ausência historicamente sustentada.]

## Custo de ampliação

[Só se a sessão abriu frente nova (país, suporte, cronologia): o que ela custa e onde
cortar.]

## Recursos HF relacionados

**Papers:** [Omitir se nenhum]
**Datasets:** [Omitir se nenhum]
**Spaces:** [Omitir se nenhum]
**Sync status:** [N] itens local / [M] itens em `warholana/iconocracy-corpus`

## Próximas buscas sugeridas

1. [query sugerida 1]
2. [query sugerida 2]
3. [query sugerida 3]

## Flags de atenção

[Itens que precisam de verificação manual, URLs instáveis, possíveis duplicatas.]
```

### Tags canônicas

> Tags `pais/` e `regime/` seguem o vocabulário vigente do repositório. As marcadas como
> v3.0 são propostas desta versão e precisam ser confirmadas lá antes de uso em massa.

```
corpus/candidato · corpus/sessao-scout · corpus/controle-negativo · corpus/zwischenraum
corpus/core · corpus/comparador · corpus/apendice                      (v3.0)
pais/BR · pais/FR · pais/UK · pais/DE · pais/US · pais/BE · (demais conforme o repositório)
suporte/moeda · suporte/selo · suporte/monumento · suporte/estampa
suporte/frontispicio · suporte/papel-moeda · suporte/cartaz
suporte/brasao · suporte/arquitetura-forense · suporte/paratexto-normativo   (v3.0)
regime/fundacional · regime/normativo · regime/militar · regime/contra-alegoria
  (só depois de leitura densa)
motivo/marianne · motivo/republica · motivo/justitia · motivo/britannia
motivo/columbia · motivo/germania · motivo/belgique
motivo/liberdade · motivo/hispania                                     (v3.0)
metodo/warburg · metodo/anacronismo · metodo/nachleben · metodo/montagem
#verificar · #verificar-data · #verificar-autoria
#verificar-imagem · #sem-iiif · #possivel-duplicata
#fora-do-core · #data-evento · #lacuna-coleta · #indisponivel-documental · #recusa   (v3.0)
#ausencia-alegorica (só ausência historicamente sustentada, com fonte)
#protocolo · #decisao-metodologica
#acoplamento-imagem-norma · #colonialidade-do-ver
#contrato-racial-visual · #contra-alegoria
#iconometria · #atlas/painel-I até #atlas/painel-VIII
#ref-hf · #análise-textual
```
