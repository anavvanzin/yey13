# Anexo 9. Comparação, vulnerabilidade e literatura

> Referência de outubro preservada. Confrontar com o núcleo e `metodo-e-fontes.md`
> antes de aplicar regras, números ou exemplos como atuais.

> Usar para cruzar fontes visuais, jurídicas e literárias, investigar lamento,
> vulnerabilidade, gênero, racialização e sátira. Procedimentos derivados criticamente
> de S4, S5, S7 e S8 (Anexo 10); casos e bibliografia continuam como pistas a verificar.
> Não transformar esta referência em um novo recorte ou em organização aprovada da tese.

## Conteúdo

1. Unidade comparativa; 2. Camadas do objeto; 3. Dupla leitura; 4. Vulnerabilidade;
5. Gênero e racialização; 6. Transferência; 7. Pistas de pesquisa; 8. Entrega.

## 1. Definir o que está sendo comparado

Identificar o estatuto de cada objeto: personificação alegórica, retrato de pessoa
histórica, personagem literária, figura retórica, testemunho ou representação institucional.
Declarar unidade, problema comum e diferenças de meio, data, jurisdição, autoria,
circulação e função. Tema compartilhado não torna os objetos equivalentes.

Personagem de romance, pessoa mencionada em relato e alegoria estatal não são unidades
intercambiáveis. Uma narrativa colonial pode esclarecer um mecanismo ou oferecer
contraponto; isso não a torna imagem elegível para o core. Um retrato pode ser alegorizado,
mas essa operação precisa de evidência; não basta a retratada ser mulher ou soberana.

A comparação pode ser transnacional e atravessar meios. Explicar o custo da extensão e
como o comparador ajuda a responder à pergunta centrada na tese. Não importar um país,
período ou conjunto de romances inteiro para resolver uma analogia pontual.

## 2. Separar imagem, inscrição, paratexto e documentação

Em mapa-poema, frontispício, medalha inscrita ou imagem publicada em periódico, localizar
cada vestígio na camada que o contém. Distinguir a figura visível, sua fala textual,
a voz narrativa e a leitura historiográfica posterior. Feridas, lágrimas ou lamento
expressos no texto não são automaticamente atributos observáveis da imagem.

Conferir se os componentes estiveram materialmente associados no exemplar/edição usado.
Não generalizar uma associação para todas as edições ou para toda a circulação. Registrar
tradução, original, página/verso e condições da reprodução; evitar atribuir ao produtor
da imagem palavras que pertencem a um comentador ou a outro agente editorial.

Para Europa regina/Europa lamentans, começar pela identificação de mapa, poema, dedicatória
e respectivas versões. A vulnerabilidade pode estar na fala, no corpo figurado, nos dois
ou só na interpretação. Não assumir um corpo visualmente ferido a partir do título do poema.

## 3. Usar a dupla leitura como teste

Examinar a proposição explícita de autoridade e, quando pertinente, suas tensões,
contradições e exclusões. Para cada leitura, procurar vestígios favoráveis, contrários e
explicações concorrentes. Admitir indeterminação ou leitura que contrarie a hipótese.

Ler "às avessas" não garante descobrir intenção repressiva, crítica oculta ou voz autêntica
do subalterno. Distinguir interpretação da pesquisadora, intenção de agentes e recepção.
Conferir obra e passagem antes de atribuir o procedimento a Stramignoni, Spivak, Benjamin
ou outro autor. Manter separados conceitos desses autores e formulações próprias de Ana.

## 4. Investigar vulnerabilidade, lamento e sátira

Usar a vulnerabilidade alegórica como pergunta sobre a distribuição da ação. Examinar:

| Questão | Vestígio ou limite a explicitar |
|---|---|
| Quem sofre e de que modo? | Postura, gesto, inscrição, narrativa, ferimento, luto, ameaça ou degradação efetivamente documentados. |
| Quem produz a ameaça ou aparece como proteção? | Agentes identificados na composição ou nas fontes; não inventar um salvador ausente. |
| Quem fala e em nome de quem? | Figura, narrador, editor, comitente ou intérprete; distinguir representação de delegação política. |
| Que ação a figura exerce? | Demanda, resistência, acusação, tutela, mobilização ou passividade, com a camada da evidência. |
| Que explicação concorre? | Convenção de lamento, motivo religioso, sátira de autoridade, mercado, mobilização patriótica ou outro contexto documentado. |
| Que efeito se conhece? | Separar função interpretada e resposta histórica comprovada. |

Tratar "dignitas ferida" e "álibi soberano" como formulações a investigar. Não concluir
que o sofrimento feminino necessariamente solicita proteção masculina ou legitima o poder.
A mesma imagem pode sustentar interpretações ambivalentes; a função não decorre do motivo.

Na sátira, verificar alvo, veículo, público e contexto. Um ataque ao governante pode
reiterar hierarquias de gênero; uma figura feminina grotesca não é automaticamente
subversão emancipatória. Não reduzir nudez a liberdade, cobertura a submissão, armamento
a poder imperial, maternidade a proteção ou doença a crítica institucional.

## 5. Contextualizar gênero, racialização e condição jurídica

Evitar "mulheres reais" como categoria jurídica homogênea. Precisar período, jurisdição,
estado civil, condição livre ou escravizada e outras categorias históricas pertinentes.
Relacionar capacidade civil, sufrágio, nacionalidade e demais posições jurídicas somente
às fontes e sujeitos que sustentam a afirmação; uma dimensão não substitui a outra.

Distinguir racialização documentada, convenção visual e hipótese da intérprete. Não
inferir identidade racial biológica de fisionomia nem embranquecimento político do branco
do mármore, do metal, de fotografia monocromática ou de reprodução alterada. Caracterizar
material, técnica, restauração e edição antes de interpretar cor ou ausência de cor.

Usar "eugenia", "biopolítica", "racialização" ou "colonialidade" com definição e mediação
histórica. Cânone clássico não comprova sozinho programa eugênico. Não tratar todos os
contextos coloniais ou pós-coloniais como uma mesma estrutura institucional.

Aplicar a distinção do núcleo entre falta de coleta, indisponibilidade e ausência
historicamente sustentada. Investigar ainda omissão, perda e supressão documentadas sem
confundi-las. O silêncio do catálogo não prova apagamento deliberado nem autoriza inventar
experiências ou falas para preencher o arquivo.

## 6. Controlar transferência e materialidade

Registrar a relação de cada par: transmissão documentada, analogia formal proposta,
contraponto jurídico, inversão identificada ou hipótese de relação. Procurar intermediários
quando se alegar transferência: gravador, oficina, modelo, encomenda, edição ou circulação.
Sem cadeia documental, reformular como comparação, sem declarar influência ou filiação.

Comparar técnica, material, dimensões, lugar de instalação e modo de circulação quando
conhecidos. Distinguir restrição do suporte, solução compositiva e causa mista/indeterminada.
Não presumir submissão diante do monumento nem interiorização da autoridade ao manusear
moeda. Comparar dentro de um suporte pode esclarecer uma hipótese, sem eliminar sozinho
explicações concorrentes. Usar o Anexo 3 para estruturar o painel e declarar seu alcance.

## 7. Encaminhar pistas bibliográficas e casos

Selecionar interlocutores conforme a pergunta; não transformar esta lista em cânone
obrigatório nem usar a descrição abaixo como citação de uma obra não consultada.

| Problema | Pistas presentes nos anexos | Conferência necessária |
|---|---|---|
| Mulher ameaçada e legitimidade colonial | Jenny Sharpe; literatura anglo-indiana; Jane Eyre | Texto literário, voz narrativa, passagem analisada e argumento efetivo da crítica. |
| Representação e subalternidade | Spivak; Hartman; Fuentes | Obra, contexto e limites de representação; evitar uma definição exclusiva de essencialismo estratégico sem fonte. |
| Lamento e corpo soberano | Kantorowicz; Loraux; Warner; Putsch e poemas | Mediações entre instituições e épocas; mapa/poema/edição concretos. |
| Venda, racialização e Justiça | Stramignoni; Capers; Bruegel; Hirsch | Identificação de objetos e inscrições; documentação específica de controvérsia e recepção. |
| Brasil e circulação atlântica | Agulhon; Landes; imprensa, moedas, selos e imagens ligadas a Villares | Exemplar, autoria, ato emissor, circulação e vínculo com documentação brasileira. |
| Construção interpretativa de dados | Drucker; discussão de capta nos relatórios | Texto e página; não atribuir método estatístico ou schema a uma fórmula teórica. |

Conceitos autorais já registrados mantêm sua atribuição a Vanzin. Uma tabela que reúna
Putsch, Rancière e Stramignoni não demonstra autoria conjunta de "iconocracia". Novos
nomes de conceitos e a fusão de Contrato Sexual Visual e Contrato Racial Visual precisam
de decisão explícita. A mera presença de uma obra na bibliografia não atesta leitura.

## 8. Entregar uma comparação que possa ser contestada

Apresentar pergunta delimitada, identificação dos objetos, fundamento da comparabilidade,
fontes consultadas, evidência separada por camada, interpretação, contraprova e limites.
Concluir apenas no alcance dos objetos examinados. Se o caso for promissor mas insuficiente,
indicar a peça documental faltante e a próxima busca. Não prometer que o caso validará a tese.
