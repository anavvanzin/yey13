# Anexo 7. Arquivo: DIR410346 (2026.1, concluída)

> Anexo especializado preservado da versão de outubro. Usar com o núcleo atual e
> `metodo-e-fontes.md`. As antigas remissões numeradas a divergências/regras pertencem
> àquela versão histórica: conferir o conflito atual antes de executar. Exemplos,
> números, comandos e ferramentas não são automaticamente fatos ou recursos atuais.

> Disciplina concluída; trabalho final ("Iconografia da autoridade jurídica: camadas de
> leitura") entregue em agosto de 2026. Mantido como referência: bibliografia do curso e
> decisões historiográficas continuam úteis para a tese. Não é modo ativo.

### Decisões historiográficas fixadas no trabalho final

- A justiça hegemônica constitui-se entre o baixo medievo e o antigo regime; nunca
  "consolidada no Estado liberal" (Sbriccoli).
- *Malleus maleficarum* (1486/1487) sistematiza, não inaugura, a categoria compósita.
- Warburg: os ensaios formulam Pathosformel/Nachleben; o Bilderatlas (ed. Warnke, 2000)
  os materializa.
- Alertas de citação: "Il canone eloquente" de Lacchè não existe (é "Il canone
  eclettico", *Quaderni fiorentini*, v. 39, 2010). SBRICCOLI 2011: p. 459–486.
- Candidata ao marco teórico da tese: HAYAERT, *Lady Justice. An Anatomy of Allegory*.

### Material original da disciplina

DIR410346: **História do Direito Penal e da Justiça Criminal** (PPGD/UFSC, Prof. Diego
Nunes, 2026.1).

#### Ementa

| Bloco | Aulas | Tema |
|-------|-------|------|
| Fundamentos | 01 | Códigos da Antiguidade e crítica metodológica |
| Pré-moderno | 02–03 | Justiça negociada → hegemônica |
| Modernização | 04–06 | Iluminismo, codificação, processo penal moderno (júri) |
| Escolas penais | 07–09 | Clássica → Positiva → Ecléticas |
| Século XX | 10–11 | Estado autoritário, tecnicismo, duplo nível de legalidade |
| Contemporâneo | 12–13 | Direito penal e constituição; transnacionalização |

#### Autores-chave

Sbriccoli (justiça negociada vs. hegemônica) · Hespanha (Antigo Regime) ·
Nilo Batista (legislação penal brasileira) · Meccarelli (criminal law before State monopoly) ·
Pietro Costa (legalidade) · Tarello (codificação) · Sontag (Escola Positiva no Brasil) ·
Diego Nunes (codificação imperial) · Luciano Oliveira (crítica epistemológica)

#### Memorial de leitura (formato usado no curso)

- **400–600 palavras** (síntese + análise)
- Tom acadêmico caloroso, prosa fluida, sem travessões como pontuação
- Síntese: tese de cada texto, conceitos operacionais, contribuição
- Análise: tensões entre textos, questões não resolvidas, conexões
- **Não ser resumo passivo**: demonstrar pensamento próprio
- Citações: ABNT NBR 6023:2025
- Salvava-se em `vault/obsidian-dir410346/aulas/Memorial XX.md`

#### Conexões com a tese

| Aula | Conexão |
|------|---------|
| 07 (Escola Clássica) | Representações da Justiça no liberalismo |
| 10 (Estado autoritário) | Iconografia da autoridade nos fascismos |
| 12 (Constituição) | Alegorias femininas da república/justiça |
| 13 (Transnacional) | Iconografia internacionalista |

#### Princípios metodológicos

1. **Anti-evolucionismo**: não há progresso linear
2. **Anti-anacronismo** (na história do direito penal): não projetar categorias modernas;
   distinto do anacronismo produtivo da montagem, que é escolha deliberada e declarada
3. **Circulação, não "influência"**: Brasil participa de circuitos transnacionais
4. **Historicidade dos conceitos**: crime, pena, legalidade mudam de sentido
5. **Fontes primárias**: privilegiar sobre manuais de segunda mão
