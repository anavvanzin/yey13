# Fluxos de trabalho

Escolher a seção correspondente ao pedido. Ajustar profundidade e formato ao problema; não executar todos os fluxos por padrão.

## Busca e ficha de corpus

Delimitar a pergunta, o conjunto e o destino: levantamento do atlas, comparação ou seleção para a tese. Buscar primeiro registros institucionais e fontes pertinentes ao objeto; manter o registro do que foi efetivamente consultado.

Inspecionar a reprodução e confrontá-la com a ficha. Registrar apenas os campos necessários ao caso: título/designação na fonte; autoria/atribuição; datas e seus tipos; suporte; relações territoriais, institucionais e políticas; identificador estável; fonte; reprodução; crédito/licença; observações; hipóteses e lacunas. Não preencher desconhecidos por inferência silenciosa.

Antes de propor novo registro, procurar duplicação por identificador e fonte, distinguindo outra reprodução do mesmo objeto de outro objeto semelhante. Conservar vínculos entre versões.

Entregar candidato em staging ou nota de revisão, conforme o destino autorizado. Promoção ao ledger canônico e publicação são operações distintas. Usar schemas e ferramentas existentes; o agente pode propor metadados com fonte, mas a gravação deve respeitar validação e autorização.

## Bibliografia e revisão de argumento

Partir da afirmação ou pergunta concreta. Distinguir descoberta bibliográfica, leitura de resumo, consulta parcial e leitura da passagem relevante. Não declarar um livro consultado porque outro autor o cita.

Para cada ponto decisivo, ligar afirmação e passagem, explicitar o alcance da fonte e registrar objeções ou explicações concorrentes. Julgar evidência pela adequação, independência e proximidade com o objeto, sem substituir crítica por contagem de referências.

Na revisão, mostrar trecho, problema, base e alteração proposta; separar estilo de conteúdo. Preservar voz e posição de Ana. Uma hipótese pode continuar aberta; não completar a demonstração com adjetivos de certeza ou alegação de ineditismo.

## Reconciliação metodológica

Ler [método e fontes](metodo-e-fontes.md). Identificar documentos e versões envolvidos, decisões explícitas e pontos ainda em debate. Comparar a regra escrita com sua aplicação em schemas, prompts, dados e interface somente até onde a tarefa exigir.

Entregar proposta com impactos e conflitos, mantendo histórico e IDs. Não reclassificar um lote, remover campos ou renomear o projeto como efeito colateral da revisão textual. Se uma regra estiver indefinida, continuar a descrição e a pesquisa independentes dela e deixar a codificação afetada pendente.

## Atlas, constelações, ensaios e glossário

Organizar portas de entrada entre objetos, fontes, conceitos e argumentos. O visitante deve conseguir reconhecer a fonte de uma informação e passar da reprodução ao registro correspondente.

Uma constelação explicita pergunta, critério de arranjo, relações propostas, diferenças preservadas, contraprova e limites. Distinguir ligação documentada de vizinhança exploratória. Não exigir transmissão provada para toda comparação nem apresentar recorrência formal como transmissão.

No glossário, separar termo histórico, conceito de um autor e formulação de Ana. No ensaio, ligar a argumentação aos objetos e fontes, evitando transformar o catálogo em prova automática. Preservar alternativas e incertezas onde sejam relevantes.

O atlas móvel pode oferecer percurso editorial próprio, com acesso às fichas e às relações essenciais. A escolha do formato depende do pedido e da composição existente; não impor canvas, grafo, accordion ou narrativa linear como solução universal.

## Revisão de site

Confirmar repositório, branch, rota e fonte realmente servida. Ler instruções locais e examinar alterações existentes antes de editar. Preservar o trabalho de outras tarefas; usar cópia isolada quando necessário.

Preparar a mudança delimitada e uma prévia. Verificar o que ela afeta: links e destinos, imagens/fontes, legibilidade, teclado/foco, modal e histórico, versões responsivas, idiomas, contraste, movimento reduzido e overflow. Usar testes existentes e acrescentar regressão quando um comportamento concreto justificar; não criar testes de mera repetição do texto.

Distinguir falha do site de bloqueio externo, CAPTCHA, cache ou indisponibilidade de ferramenta. Não contornar restrições de acesso. Não converter um teste local em certificação de produção ou de navegador não testado.

Entregar arquivos/commit quando autorizado, URL da prévia, mudanças, verificações aprovadas/falhas/não executadas e decisões restantes. Aprovação de edição ou prévia não autoriza deploy, merge ou alteração de configurações públicas.


## Execução detalhada e estado do projeto

Para contratos de tarefa, matrizes de versão, registro de afirmações, revisão de parecer,
apresentações e experimentos separados, consultar [protocolos do agente](protocolos-agente.md).
Para versões e pendências datadas, consultar [estado de 05/11](estado-projeto-2026-11-05.md).
Rever o estado antes de agir: a data desta referência não transforma uma entrega pendente
em concluída nem prolonga uma autorização antiga.
