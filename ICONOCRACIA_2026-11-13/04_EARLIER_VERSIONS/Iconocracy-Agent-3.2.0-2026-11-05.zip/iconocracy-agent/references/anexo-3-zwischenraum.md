# Anexo 3. Modo ZWISCHENRAUM: montagem warburguiana

> Anexo especializado preservado da versão de outubro. Usar com o núcleo atual e
> `metodo-e-fontes.md`. As antigas remissões numeradas a divergências/regras pertencem
> àquela versão histórica: conferir o conflito atual antes de executar. Exemplos,
> números, comandos e ferramentas não são automaticamente fatos ou recursos atuais.

Modo em que a montagem produz conhecimento sobre as imagens, em vez de ilustrar uma tese
pronta. Gera painéis warburguianos que estabelecem o espaço de tensão (*Zwischenraum*)
entre manifestações de uma figura, no espírito do *Bilderatlas Mnemosyne* como
instrumento de pensamento (*Denkinstrument*), não como prancha decorativa.

#### Conteúdo

Fundamento; materialidade e legenda; estrutura do painel; template de nota.

#### Fundamento epistemológico

- **O sentido nasce no intervalo.** Seguindo a "iconologia do intervalo" (Warburg) e a
  colisão que produz um terceiro sentido (Eisenstein), o trabalho analítico acontece nos
  *Zwischenräume* entre as figuras, não em cada figura isolada.
- **Nachleben, não influência.** A unidade de análise é a *Pathosformel* que **sobrevive**,
  se reativa e se inverte através de contextos e séculos. Mostrar a migração da fórmula,
  não uma linha de causa.
- **Anacronismo produtivo (Didi-Huberman).** É legítimo montar uma Marianne do XIX, uma
  Justitia do XVI e uma ninfa antiga juntas: a imagem jurídica é montagem de tempos
  heterogêneos. O anacronismo é o tempo próprio das imagens, não um erro a evitar.
  A escolha se declara no painel; polos externos ao recorte explicitado entram como
  comparadores e ficam fora de suas contagens. Distinguir tese, catálogo e atlas. Projeção não declarada de categorias atuais é presentismo e se
  aponta.
- **Disciplina da relação.** Documentar a proveniência de cada objeto e declarar o
  estatuto de cada vínculo: transmissão documentada, analogia formal proposta,
  contraponto jurídico, inversão identificada ou relação ainda em investigação.
  Alegar migração exige evidência histórica pertinente; uma analogia justificada pode
  integrar o painel sem virar genealogia. Vizinhança gráfica não produz essa evidência.
  Explicitar o fundamento da comparabilidade e preservar diferenças de cronologia,
  jurisdição, instituição, suporte e função. Nenhuma medida agregada ordena polos.
- **A montagem é argumento** (`DEC-2026-07-29`): o critério do arranjo se declara, e o
  painel sustenta afirmações sobre produção e circulação de sentido, não sobre recepção.

#### Materialidade e legenda

Distinguir dimensão do objeto, escala de sua reprodução e condições de observação.
Indicar técnica, material, instalação, circulação e edição quando conhecidos. Não usar
escala gráfica ou normalização métrica sem medidas; dimensão desconhecida fica declarada.
Comparar meios distintos exige essa restituição material, sem presumir efeitos sobre o
espectador. A moldura da reprodução não é necessariamente elemento da composição original.

Usar convenções gráficas apenas com legenda. Linha contínua/tracejada pode distinguir
transmissão de analogia, mas não é padrão obrigatório nem medida de força histórica.
Se houver espaço vazio ou *Shadow Frame*, dizer se representa imagem não vista,
indisponibilidade, perda, divergência documental ou supressão comprovada. Não representar
essas situações como o mesmo apagamento; alternativas de arranjo devem permanecer visíveis.
Core/comparador/apêndice e estado de verificação são eixos independentes; comparadores
podem integrar painéis sem entrar nas contagens do core. IIIF ou alta resolução não
promovem um objeto nem certificam seu contexto. Ver Anexos 8 e 9 para mediações e comparação.

#### Estrutura do painel

1. **Dados comparados** (quando mesmo suporte): metal, peso, diâmetro, casa da
   moeda, desenhista, área de circulação; estatuto de cada polo (core ou comparador)
2. **Fundamento da comparabilidade e diferenças preservadas** (cronologia, jurisdição,
   instituição, suporte, função)
3. **Proveniência dos objetos e estatuto da relação**, com evidência do vínculo ou
   justificativa da analogia/contraposição, sem confundir esses planos
4. **O que muda no intervalo**: gesto, atributo, suporte, circulação, inscrição; que
   operação de autoridade se desloca entre os polos
5. **Corpo, gênero e raça** nos polos (se pertinente)
6. **Contraprova**: o que, no intervalo, resiste à leitura proposta
7. **O que o painel permite afirmar, e o que não permite** (recepção incluída)
8. *(Opcional, se Ana pedir)* indicadores que variam entre os polos, em apoio à montagem,
   nunca em substituição a ela

Output como nota Obsidian `tipo: corpus-zwischenraum` (template abaixo).

#### T2. Nota Zwischenraum (`corpus-zwischenraum`)

Arquivo: `SCOUT-ZW-[NN] Painel [N] [título curto].md`, padrão dos painéis existentes. Em
Claude Code, o hook bloqueia esse nome dentro de `vault/candidatos/`: confirme com Ana a
pasta antes de gravar (divergência 9).

```markdown
---
id: SCOUT-ZW-[NN]
tipo: corpus-zwischenraum
status: ativo
titulo: "Painel [N] -- TÍTULO: Polo A x Polo B"
pais: [CC, CC]
periodo: "YYYY-YYYY"
criterio_do_arranjo: "por que estes polos, e não outros"
tags:
  - corpus/zwischenraum
  - painel/[tema]
  - metodo/warburg
related:
  - "[[CC-NNN]]"
  - "[[CC-NNN]]"
  - "[[Conceito ou problema da tese]]"
data_scout: YYYY-MM-DD
---

## Painel [N] -- TÍTULO (Zwischenraum)

Este painel estabelece o espaço de tensão (*Zwischenraum*) entre [descrição].

**Polo A ([País, Ano]):** *Título* (Criador). Caracterização breve.
**Polo B ([País, Ano]):** *Título* (Criador). Caracterização breve.

### Dados Comparados

| Elemento | Polo A | Polo B |
|----------|--------|--------|
| **Item** | [título] | [título] |
| **Estatuto no recorte** | [core/comparador/apêndice] | [core/comparador/apêndice] |
| **Evidência consultada** | [imagem, exemplar, metadados; lacunas] | [imagem, exemplar, metadados; lacunas] |
| **Datas** | [criação/edição; evento se houver] | [criação/edição; evento se houver] |
| **Suporte e técnica** | [detalhes] | [detalhes] |
| **Dimensões/escala** | [medida conhecida ou lacuna] | [medida conhecida ou lacuna] |
| **Desenhista** | [nome] | [nome] |
| **Circulação** | [onde] | [onde] |
| **Contexto institucional** | [contexto] | [contexto] |

### 1. Fundamento da comparabilidade

[Em que base os polos podem ser comparados; que diferenças de cronologia, jurisdição,
instituição, suporte e função se preservam.]

### 2. Proveniência e relação

[Identificar cada objeto e declarar a relação: transmissão documentada, analogia formal
proposta, contraponto jurídico, inversão identificada ou hipótese. Indicar a evidência
ou a justificativa; explicitar relações alternativas e a legenda gráfica, se utilizada.]

### 3. O que muda no intervalo

[Gesto, atributo, suporte, circulação; que operação de autoridade se desloca.]

### 4. Corpo, gênero e raça

[Se pertinente.]

### 5. Contraprova

[O que resiste à leitura proposta.]

### 6. Alcance e limites

[O que o painel sustenta e o que não sustenta, recepção incluída.]
```
