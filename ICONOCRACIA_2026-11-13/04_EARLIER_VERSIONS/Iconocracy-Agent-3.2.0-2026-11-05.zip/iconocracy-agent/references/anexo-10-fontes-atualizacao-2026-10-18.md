# Anexo 10. Fontes e reconciliação da atualização de 18/10/2026

> Referência de outubro preservada. Confrontar com o núcleo e `metodo-e-fontes.md`
> antes de aplicar regras, números ou exemplos como atuais.

> Consultar quando os oito insumos abaixo reaparecerem em pedidos de método, pesquisa ou
> revisão. Este registro permite reconhecer as versões e evitar a reintrodução de
> procedimentos substituídos. É parte operacional da skill v3.1; não é decisão nova da tese.
> Os arquivos originais foram lidos como insumos e não foram alterados nesta atualização.

## Conteúdo

1. Identidade dos insumos; 2. Incorporação; 3. Conferência canônica;
4. Divergências; 5. Integridade de afirmações e citações; 6. Uso futuro.

## 1. Identidade dos insumos

Recebidos em 18/10/2026. SHA-256 calculado sobre os bytes de cada anexo original.
Hashes distinguem arquivos e versões; não validam fatos, não atestam autoria e não
permitem recuperar o conteúdo por si sós. Não confundir S1 com outro `Pasted text.txt`.

| ID | Nome recebido | SHA-256 |
|---|---|---|
| S1 | `Pasted text.txt` | `c340865aedec050eedd0c3549af0383d94cf26aa25c790981894d3f504119102` |
| S2 | `Filosofia_da_pesquisa_para_a_ICONOCRACY_guia_metodologico.docx` | `617a428cb3adcae0bf8f591a93e7765d462db52d501669b4d3c3cea3facedfa5` |
| S3 | `Filosofia_da_pesquisa_para_a_ICONOCRACY_guia_metodologico_(edicao_revista).docx` | `cfa5ce95414dc4f3d6301cb8eca517bf09e95355c3f2d88c2a92e12b9a1ab5ac` |
| S4 | `01-Doutorado.md` | `ca4b695e7555df2be822b074407f328aa2525680c37ddd03f4cc70a52e98c653` |
| S5 | `02-Comparative Literature Primer Tropes of Gender, Race, and Authority in Colonial Texts.md` | `d122d90cc540a38c27fabced86493efce2e7a7a5684d77523cfed7e7a834a0f7` |
| S6 | `03-Research Methodology Blueprint Operationalizing Non-Composite Iconometric Analysis in Digital Legal .md` | `4ab713a3685dfd77565eb2801ef51ae4bfece83e3f69497cd1ed506da21990e1` |
| S7 | `04-THE ANATOMY OF ALLEGORICAL VULNERABILITY A Comparative Case Study of Female Suffering, State Legitim.md` | `e12b86fa75d00218a2440a11d6caf5cb893f40e4e6443b8baa257b92b407cd96` |
| S8 | `05-Cross-Media Visual Montages in Legal History A Research Framework for Legal Iconology and Iconocracy.md` | `9a9d03d89c78b30f6c2b9506c64fa29ba00f0fb7ea55730c2904be9cdf044d08` |

S1 se intitula **Metodologia (v.1)** e declara o encontro de 09/04/2026. S4 se intitula
**A Gramática da Iconocracia: Mediação Jurídica e Transferência Transnacional nas
Alegorias da República (1822–1922)**. Os demais títulos internos correspondem aos temas
dos nomes recebidos. Data de recebimento não é data de decisão ou publicação.

## 2. O que foi incorporado

| Insumo | Contribuição usada | Limite mantido |
|---|---|---|
| S1 | Pergunta histórico-interpretativa, unidade iconográfica, documentação contextual e vieses de arquivo. | Documento histórico; suas prescrições métricas e geográficas não regem o método atual. |
| S2 | Explicitação de pressupostos, posição da pesquisadora e relação entre filosofia e operações. | Guia pedagógico; tabelas não escolhem automaticamente um paradigma. |
| S3 | Subordinação das contagens (§5.4), articulação Panofsky–Warburg (§3.4), reflexividade e objeção de anacronismo (§8.3). | Preferido a S2 nas passagens revistas, sem elevar suas afirmações ou referências a verificadas. |
| S4 | Dossiê imagem–norma, suporte/escala, circulação transnacional e teste da dupla leitura. | Série brasileira e interpretações permanecem dependentes de objetos e documentos identificados. |
| S5 | Comparação entre tropos literários, alegoria, representação e subalternidade. | Comparabilidade não implica elegibilidade no core, equivalência de objetos ou recuperação de voz sem fonte. |
| S6 | Indicadores separados, controle material, legenda de relações e integridade de versões. | Não importar novos tiers, nomes/numeração de indicadores, campos ou estados empíricos do relatório. |
| S7 | Vulnerabilidade, lamento, distribuição da ação e ambivalência da sátira. | Hipóteses comparativas, sem mecanismo universal ou correlação visibilidade–capacidade demonstrados. |
| S8 | Montagem entre meios, proveniência de vínculos, escala e explicitação de lacunas. | Painéis e recursos gráficos são possibilidades; não constituem arquitetura aprovada do atlas ou da tese. |

S3 acrescenta bibliografia e entradas de glossário, além das melhorias argumentativas.
Essa adição não certifica as referências nem promove "Epônima", "Mãe-pátria" ou
"Presidência totemizada" a categorias canônicas. As seis entradas bibliográficas novas
em relação a S2 tampouco receberam conferência externa nesta atualização.

## 3. Base canônica efetivamente conferida

Repositório: [iconocracy-corpus, commit 84b256c](https://github.com/anavvanzin/iconocracy-corpus/commit/84b256ce49a30050c28e113cb1b28b11c2982053),
consultado em 18/10/2026. A atualização da skill anterior usava `dc5363b`.
A mudança entre os dois commits integra o dossiê Mnemosyne e sua navegação, sem alterar
as decisões do método. A nota de integração se declara editorial, não decisória.

Documentos consultados no commit indicado, integralmente ou nas determinações pertinentes:

- `README.md`, `CLAUDE.md` e `AGENTS.md`;
- `docs/METHOD_CONTRACT_2026-07-31.md`;
- `docs/decisions/2026-07-28-aposentadoria-do-indice-composto.md`;
- `docs/decisions/2026-07-29-aparato-minimo-suficiente.md`;
- `docs/decisions/2026-07-31-metodologia-2-0-iconometry-consolidation.md`;
- `docs/decisions/2026-09-22-auditoria-camada-inferencial.md`;
- `docs/decisions/2026-09-24-remocao-definitiva-do-campo.md`, incluindo a verificação de 29/09;
- `docs/decisions/E1-PRE1800-COHORT-2026-06-22.md`;
- `docs/adr/006-canonical-field-ownership-and-projections.md`;
- `docs/research/integracao-mnemosyne-2026-10-15.md`.

Não se recontaram os ledgers, não se recodificaram imagens, não se reexecutaram notebooks
e não se certificou a bibliografia desses documentos. A menção da nota Mnemosyne a
MASTER 2.2.1 e piloto 2.3.0 informa uma divergência; não equivale a nova inspeção dos
codebooks. Recuperar a versão realmente aplicada em cada observação antes de operar.

Precedências verificadas: 29 e 31/07 superam kappa como requisito/prova ainda presente
em 28/07; 24/09, esclarecida em 29/09 no mesmo arquivo, supera a manutenção de composto
em dados ativos ainda indicada em julho. O contrato preserva números históricos que não
substituem contagem datada. As justificativas teóricas dessas decisões não devem circular
como demonstrações universais sobre os pressupostos de técnicas estatísticas.

## 4. Divergências que não foram convertidas em decisões

| Tema | Ocorrência nos insumos | Tratamento vigente |
|---|---|---|
| Escore e escala | S1 §§3–7: 0–4, média de endurecimento e comparação de médias. | Dez indicadores separados 0–3; não importar, recalcular ou converter aritmeticamente o composto. |
| Confiabilidade e fechamento | S1 §§6–7: rodadas independentes, intervalo, kappa, limiar e saturação por escores. | Aparato mínimo; diagnóstico interno apenas no escopo apropriado; N aberto e versões identificadas. |
| País como gate | S1 §5: seis jurisdições como critério cumulativo. | País é variável analítica; não reinstalar o quinto critério. |
| Cronologia | S1: 1800–2000; S2/S3: 1239–1975; S4: 1822–1922 com extensão textual a 1932/1934. | Distinguir foco da tese, core do catálogo, coorte anterior, comparador e evento; adjudicação formal permanece com Ana. |
| N e unidade | S2/S3: 145 itens, 51 figuras, 15 países e 20 mães-pátria; S6/S8: 336/286 em snapshots. | Não reconciliar por cópia; itens, figuras e observações têm unidades e versões distintas. Sem recontagem nesta atualização. |
| Novos tiers | S6–S8 misturam elegibilidade, acesso e completude. | Separar escopo e estado de evidência; não promover/excluir automaticamente nem exigir inspeção física universal. |
| Indicadores e schema | S4/S6/S8 oferecem camadas, numeração e protocolos como atuais. | Consultar codebook e schema; manter `purificacao.atributos_iconograficos`, sem campos paralelos. |
| Agência e causalidade | S1–S8 por vezes fazem a imagem legislar, disciplinar ou validar a hipótese por definição. | Proposição a testar; separar normatividade simbólica, prescrição, intenção e recepção. |
| Termos e autoria | S4/S7 fundem contratos ou propõem `dignitas ferida`; S5 combina autores sob iconocracia. | Preservar conceitos registrados e suas autorias; novos conceitos/fusões continuam propostas. |
| Edição de Mondzain | S2/S3 citam 2005; projeto prefere 2002. | Conferir obra, edição e paginação efetivas, sem troca automática de ano. |

## 5. Pontos concretos de integridade

Estas ocorrências foram identificadas nos anexos; não são uma auditoria bibliográfica
externa completa. Servem para impedir reutilização acrítica e orientar a próxima busca.

- **S1 §§2 e referências:** nomes de autores no corpo divergem dos nomes da entrada
  bibliográfica correspondente. Não normalizar por adivinhação; localizar a obra.
- **S1 §3:** `48C51` é usado como Iconclass de alegorias estatais. Aplicar a distinção
  já documentada no núcleo entre notação oficial e rótulo interno `custom`.
- **S4 §2:** linguagem de exclusão constitucional expressa, incapacidade e antecipação
  normativa exige conferência dos textos históricos e dos sujeitos alcançados. Não
  equiparar exclusão expressa, interpretação restritiva e prática social.
- **S4 §§2 e 5:** 1822–1922 é apresentado como ciclo de 110 anos e a série incorpora
  1932/1934. Corrigir a inconsistência interna; explicitar qualquer extensão cronológica.
- **S4 §4 e S8 §6.3:** interpretações da venda e relatos sobre o mural de Hirsch exigem
  objeto, documentos de controvérsia e recepção específicos; não usar uma explicação causal
  da censura apenas porque ela coincide com a hipótese.
- **S5 §3.1:** a citação atribuída a Jane Eyre contém `Android-like`. Tratar como suspeita;
  localizar a edição e a passagem antes de citar, traduzir ou propor texto substituto.
- **S5 §4.2:** a definição de essencialismo estratégico como exclusivamente escrita e
  nunca ação política é categórica; conferir a obra e o contexto de Spivak.
- **S7 abertura do §4:** a data de 1922 é associada ao centenário da Primeira República,
  em conflito com 1889 no próprio arquivo. Não reproduzir a cronologia do relatório.
- **S7 §5.2:** a "correlação inversa direta" entre visibilidade alegórica e capacidade
  jurídica não vem acompanhada de demonstração; tratar a assimetria como hipótese.
- **S7 §2.1:** "nunca circulou" isolado e "permanentemente unido" ao poema extrapolam
  a identificação de um exemplar; conferir versões e circulação.
- **S7 §2.2 e S8 §6.2:** identidade da gravura de 1598, relação com Elizabeth I e a
  interpretação proposta precisam de verificação independente.
- **S8 §6.3:** a ligação de uma imagem de 1559 à teoria penal de Grotius apresenta risco
  de anacronismo; conferir cronologia e fonte antes de falar em influência, admitindo
  apenas comparação retrospectiva explicitada quando historicamente pertinente.
- **S6 §2, S7 §6 e S8 §5:** diagnósticos de FR-025–FR-029 e US-020 são relatos de
  trabalho; consultar os registros atuais antes de chamar a situação de pendência viva.

## 6. Como reutilizar os materiais

Recuperar o arquivo pertinente e conferir versão/hash quando necessário. Usar os
procedimentos sintetizados nos Anexos 3, 8 e 9, preservando o estatuto de cada afirmação.
Para uma citação ou fato histórico, procurar a fonte primária/especializada adequada e
registrar edição, localizador e acesso. Não citar esta síntese como prova da história.

Quando Ana autorizar nova decisão, registrar o conteúdo e o escopo dessa decisão e
atualizar apenas as divergências por ela resolvidas. Quando pedir revisão de um documento,
aplicar as correções autorizadas ao documento solicitado; a atualização desta skill não
substitui a edição dos oito originais nem da tese.
