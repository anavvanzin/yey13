# Anexo 4. Regimes, recusas e inventário verbal

> Anexo especializado preservado da versão de outubro. Usar com o núcleo atual e
> `metodo-e-fontes.md`. As antigas remissões numeradas a divergências/regras pertencem
> àquela versão histórica: conferir o conflito atual antes de executar. Exemplos,
> números, comandos e ferramentas não são automaticamente fatos ou recursos atuais.

> Estatuto (`DEC-2026-07-29-APARATO-MINIMO`): os regimes iconocráticos são tipologia
> analítica construída pela leitura densa de casos exemplares; o inventário verbal e a
> tipologia de recusas operam sob o paradigma indiciário. Nada aqui é resultado da tese, e
> nada se deriva de agregação de indicadores. Use este anexo para ler e recodificar itens,
> preparar leitura densa e testar as tipologias contra casos que não se encaixam. A mesma
> decisão (§6) suspendeu a afirmação sobre o regime militar enquanto seus registros
> estivessem majoritariamente não codificados: confira no ledger se a suspensão ainda vale
> antes de afirmar algo sobre esse regime.

### Conteúdo

Regimes e casos-limite; tipologia de recusas; indicadores e inventário; legado.

### Regimes iconocráticos

A ordem abaixo não descreve sequência necessária. Transições se documentam caso a caso, e
item que não se encaixa é dado. As listas de marcadores são indícios para a leitura densa,
não checklist de atribuição. As contra-alegorias são teste crítico do regime, não catálogo
amplo (`METHOD_CONTRACT_2026-07-31`). O `AGENTS.md` conta três regimes; o schema aceita
`contra-alegoria` como quarto valor de `regime_iconocratico`, fora da progressão.

#### FUNDACIONAL (sacrificial-fundacional)

Fundação do Estado, independência, constituições, revoluções. O corpo alegórico
está em seu estado mais vivo: dinâmico, exposto, até sacrificial.

**Marcadores visuais:**
- **Peito nu / seminudez**: a Marianne revolucionária, a Liberty de Delacroix
- **Barrete frígio**: gorro vermelho da liberdade, atributo revolucionário
- **Corpo dinâmico**: correndo, avançando, braço erguido, liderando a carga
- **Armas seguradas agressivamente**: pique, baioneta, bandeira-como-arma
- **Sangue / sacrifício**: cenas de barricada, corpos caídos ao lado da alegoria
- **Correntes quebradas**: escravidão abolida, tirania derrubada
- **Fasces**: feixe de varas, autoridade republicana romana
- **Tocha erguida**: iluminação, Iluminismo
- **Coroas / cetros pisoteados**: monarquia derrotada sob os pés
- **Sol nascente**: novo amanhecer, nova era
- **Constituição / tábuas**: segurando ou apresentando o texto fundacional
- **Controvérsia da nudez**: quando o corpo é "exposto demais" para o suporte
  (cf. $5 Educational "dirty dollars", EUA, 1896)

**Suportes típicos:** gravuras revolucionárias, medalhas comemorativas, papel-moeda
de fundação, frontispícios constitucionais

#### NORMATIVO (burocrático-estabilizado)

República estabilizada, rotina burocrática. A alegoria é domesticada: vestida,
controlada, infinitamente reproduzível.

**Marcadores visuais:**
- **Corpo totalmente vestido**: drapeado clássico mas cobertura completa
- **Pose frontal ou ¾**: estável, simétrico, sem movimento
- **Postura sentada**: entronizada, estática, ancorada
- **Balança da justiça**: equilibrada, imparcial, institucional
- **Venda nos olhos**: distanciamento de Justitia da paixão
- **Livro / código legal**: segurando texto de lei, não constituição
- **Coroa de louros**: vitória domesticada em virtude cívica
- **Cornucópia**: abundância, prosperidade, não revolução
- **Face genérica**: sem traços individuais, intercambiável
- **Enquadramento arquitetônico**: pilastras, frontão, cartela, borda ornamental
- **Monocromo / metálico**: redução de cor (selos, moedas)
- **Semeando sementes**: modelo Semeuse, produtiva, nutridora, pacífica
- **Produzida em massa**: milhões de cópias idênticas (serialidade máxima)

**Suportes típicos:** selos definitivos, moedas circulantes, edifícios governamentais,
papelaria oficial

#### MILITAR (imperial-militar)

Guerra, imperialismo, expansão colonial, mobilização. O corpo endurece. (A v2.0 dizia que
aqui o endurecimento chegava ao máximo; a afirmação dependia do composto aposentado e está
suspensa até leitura efetiva.)

**Marcadores visuais:**
- **Capacete**: Britannia com elmo, Germania com Pickelhaube, Minerva com elmo ático
- **Escudo**: postura defensiva, protegendo a nação
- **Espada / tridente**: armas ofensivas (tridente de Britannia = império naval)
- **Armadura / couraça**: corpo literalmente blindado, metalizado
- **De pé sobre globo / mapa**: domínio imperial sobre território
- **Proa de navio**: poder naval, projeção colonial
- **Leão aos pés**: poder régio, leão imperial britânico
- **Águia**: águia imperial alemã, águia dos EUA
- **Sujeitos coloniais abaixo**: figuras racializadas subordinadas à alegoria branca
- **Corpo rígido**: duro, monumental, sem movimento
- **Olhar frontal**: intimidador, soberano
- **Troféus militares**: canhões, bandeiras, tambores na base
- **Moedas de comércio**: British Trade Dollar (Britannia para colônias asiáticas),
  Piastre de Commerce francesa (Marianne para Indochina)

**Suportes típicos:** medalhas de guerra, moedas e selos coloniais, monumentos
militares, cartazes de propaganda

#### CONTRA-ALEGORIA (teste crítico; valor técnico fora dos três regimes)

Quarto valor do enum no schema (`contra-alegoria`), não quarto regime analítico. Fica fora da progressão, como seu
ponto de fratura: subversões, paródias, reapropriações feministas, respostas
anticoloniais, e a recusa do cânone alegórico. Aqui a *Pathosformel* sobrevive invertida:
a venda da Justitia ou a Marianne ressignificada são hipóteses a confrontar com cada
exemplar e contexto. Classificar como `contra-alegoria` somente quando a leitura
documentada sustentar citação do cânone para negá-lo ou desestabilizá-lo. Sátira não
comprova emancipação; investigar também hierarquias reiteradas (Anexo 9).

**Marcadores típicos:** caricatura, sátira, montagem crítica, gesto canônico invertido,
suporte não estatal (imprensa, panfleto, arte engajada), legenda irônica.

#### Transições entre regimes e casos-limite

**Nem todo item se encaixa.** Observar:
- **FUNDACIONAL → NORMATIVO**: investigar reconfigurações de uma figura por séries
  identificadas, sem pressupor domesticamento linear nem equiparar figuras distintas.
- **NORMATIVO → MILITAR**: investigar mudança de uso em contextos de guerra; comparar
  Semeuse e Germania é contraste entre figuras, não prova de trajetória de uma só.
- **MILITAR → CONTRA-ALEGORIA**: o cânone endurecido vira alvo de paródia ou recusa
- **Corpos que cruzam regimes**: ex.: $5 Educational (corpo FUNDACIONAL em suporte
  NORMATIVO = escândalo)
- **Recusa** (`#recusa`; tipologia abaixo): o corpo feminino deixa de comparecer, ou é
  substituído, num suporte que o comportaria (ex.: a águia da República de Weimar no lugar
  de Germania). Distinguir da contra-alegoria: recusa é não-comparecimento ou substituição;
  contra-alegoria é negação ativa que cita o cânone. `#ausencia-alegorica` fica reservada à
  ausência historicamente sustentada, com fonte.

### Tipologia de recusas

Formulada na varredura de 2026-07-24 (`corpus/docs/2026-07-24_varredura-recusas.md`: 13
recusas confirmadas entre 26 candidatas) e fundamentada em
`corpus/docs/2026-07-24_fundamentacao-teorica-recusas.md`. Recusa é a situação em que o
corpo feminino de Estado deixa de comparecer, ou é substituído, num suporte
jurídico-político que o comportaria; o que se inventaria é o que entra no lugar. Mecanismos
registrados:

1. **substituição remasculinizante:** águia, leão, perfil do soberano, brasão, clero, mãos
   masculinas armadas;
2. **negação pura:** vazio, sem substituto figurativo (destruição, remoção);
3. **feminino-esvaziado:** a forma feminina permanece, degradada, envelhecida ou grotesca
   (tipo Anastasie);
4. **abstração neutra:** sem marcador de gênero legível (a esfera celeste do brasão
   brasileiro).

A varredura deixou para Ana decidir um caso limítrofe, a remasculinização por deslocamento
(US-020): confira se a decisão já foi registrada. A remasculinização é um mecanismo entre
quatro, não lei geral; a literatura contrária examinada na fundamentação impede
generalizá-la. Toda recusa depende de distinguir ausência substantiva de ausência de
coleta. A `DEC-2026-07-29` registrou como lacuna a teoria do silêncio documental que
sustenta as recusas (Trouillot em segunda mão; Farge, Hartman e Fuentes a ler): confirme o
estado dessa leitura antes de redigir. Nos registros verificados, o campo `recusa` traz a
espécie (`recusa-iconoclástica`, `ausência`, `substituição-heráldica`) e o substituto; o
campo não consta do schema declarado e passa por `additionalProperties`.

### Inventário verbal sobre os 10 indicadores

Escala ordinal 0–3, com as âncoras do `codebook-MASTER` v2.2.1, §10 (conferir a versão
vigente antes de codificar):

| Indicador | 0 | 1 | 2 | 3 |
|---|---|---|---|---|
| `desincorporacao` | corpo naturalista | idealizado | genérico | geométrico/ausente |
| `rigidez_postural` | movimento dinâmico | pose contida | rígida/frontal | hieratismo total |
| `dessexualizacao` | erotismo/nudez explícita | sugestão corporal | coberto mas generificado | gênero indeterminado/encoberto |
| `uniformizacao_facial` | rosto individualizado | idealizado | genérico | sem rosto/máscara |
| `heraldizacao` | atributo integrado | portado | destacado | emblema isolado |
| `enquadramento_arquitetonico` | espaço aberto | fundo discreto | moldura dominante | absorvido por edifício/selo |
| `apagamento_narrativo` | cena completa | narrativa sugerida | figura isolada com vestígio | fundo neutro/isolamento total |
| `monocromatizacao` | policromia | paleta reduzida | bicromia/restrita | monocromático |
| `serialidade` | obra única | tiragem limitada | média escala | reprodução massiva |
| `inscricao_estatal` | sem vínculo estatal | encomenda oficial | insígnia estatal | dispositivo estatal |

Regras:

- frase justificativa obrigatória para cada atributo marcado (`DEC-2026-07-29`), dizendo
  onde o traço se vê; `dessexualizacao` e `apagamento_narrativo`, de fronteira mais
  subjetiva, pedem justificativa ainda mais explícita;
- os atributos observados e suas justificativas vão em `purificacao.atributos_iconograficos`
  (lista de strings; divergência 8);
- `null` = não codificado; 0 = ausência observada; ausência de codificação nunca aparece
  como zero;
- nunca somar, tirar média, contar atributos ou produzir número único; não fabricar
  justificativa verbal a partir de limiar numérico;
- o regime não se deriva dos indicadores;
- no modo SCOUT, descrever em linguagem natural os traços visivelmente ativos (ex.: "corpo
  inteiramente coberto"); no ICONOCODE, graduar com justificativa;
- a varredura de recusas de 2026-07-24 usou uma gradação verbal de cinco termos (ausente,
  mínimo, moderado, pronunciado, extremo), que não corresponde termo a termo à escala 0–3:
  não converter uma na outra sem regra registrada.

**Legado.** O índice composto foi aposentado em 28/07/2026; a decisão de 24/09,
com verificação operacional de 29/09, removeu os campos agregados dos dados ativos e
exports. Preservar documentos históricos datados e snapshots como história do trabalho;
não restaurar valores `legacy_frozen` em dados ativos nem calcular sucedâneos. Nenhuma
afirmação vigente repousa sobre eles. Codificações 0–4 são incompatíveis com o contrato
atual: se houver recodificação autorizada, rever imagem, âncoras e versão; não fazer
conversão aritmética automática para 0–3. Na prosa teórica, endurecimento continua designando o eixo de fixidez da
iconometria, que operacionaliza a Purificação Clássica nos 10 indicadores (`CLAUDE.md`).
