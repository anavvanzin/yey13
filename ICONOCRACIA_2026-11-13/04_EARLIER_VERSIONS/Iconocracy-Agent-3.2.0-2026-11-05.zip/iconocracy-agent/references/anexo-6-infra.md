# Anexo 6. Infraestrutura do repositório

> Anexo especializado preservado da versão de outubro. Usar com o núcleo atual e
> `metodo-e-fontes.md`. As antigas remissões numeradas a divergências/regras pertencem
> àquela versão histórica: conferir o conflito atual antes de executar. Exemplos,
> números, comandos e ferramentas não são automaticamente fatos ou recursos atuais.

> Comandos conferidos no `AGENTS.md` e no `CLAUDE.md` em 2026-10-14 (commit `dc5363b`); se
> divergirem dos vigentes, valem esses arquivos. Rode sempre a partir da raiz do
> repositório, confirmada antes (o caminho local mudou com a migração de máquina). Nada de
> escrita (sync, commit, edição de records) sem autorização explícita de Ana.

Ambiente: `conda activate iconocracy`. Em agente de nuvem sem conda, rodar
`python tools/scripts/<script>.py` e `python -m pytest tests/`.

#### VALIDAR

```bash
python tools/scripts/validate_schemas.py
python tools/scripts/validate_schemas.py data/processed/records.jsonl --schema master-record --verbose
```

`check_thesis_terms.py` (termos proibidos e atribuições erradas) só quando Ana pedir (ver
Vocabulário).

#### PURIFICAÇÃO (codificação)

```bash
python tools/scripts/code_purification.py --status
python tools/scripts/code_purification.py --item ID   # ou --batch SIGLA | --export-csv
```

#### SYNC

```bash
python tools/scripts/vault_sync.py status           # status | diff | pull | push | sync
python tools/scripts/records_to_corpus.py --diff    # antes de tocar corpus-data.json
python tools/scripts/sync_companion.py              # superfície derivada do Companion
```

Nunca editar `corpus/corpus-data.json` à mão. `notion_sync.py` e `make_index.py` existem em
`tools/scripts/`, mas não constam do `AGENTS.md`: confirme o uso vigente antes de rodar.

#### RELEASE GATE (ordem do `AGENTS.md`; parar no primeiro que falhar)

```bash
python tools/scripts/validate_schemas.py
python tools/scripts/code_purification.py --status
python tools/scripts/vault_sync.py status
python tools/scripts/records_to_corpus.py --diff
python tools/scripts/build_hf_release.py
```

Relatório final em tabela: Step | Status | Details.

#### ARGOS (aquisição)

```bash
python tools/scripts/argos_build_manifest.py
python tools/scripts/argos_prepare_dispatch.py --manifest data/raw/argos/manifest.json
python tools/scripts/argos_report.py
```

#### COMPILAR

```bash
make -C vault/tese/ docx   # tese completa em DOCX
make -C vault/tese/ pdf    # PDF; exige LaTeX
```

Desde a correção integrada em 24/10, as fontes canônicas de build estão em
`tese/manuscrito/`; `vault/tese/Makefile` as compila, e capítulos no vault são espelhos.
Preservar `*_original`; localizar e editar a versão-fonte autorizada, não um espelho
apenas porque está no vault. Ver os comandos e saídas atuais em `estado-projeto-2026-11-05.md`. Se a compilação falhar, diagnosticar (pacotes LaTeX, frontmatter YAML,
referências cruzadas).

Guardrails do repositório: `data/raw/` só com metadados (binários no Drive, ADR-001); os
campos de alegoria do Codebook v2 (`subtipo`, `familia_alegorica`, `vetor_colonial`,
`hipotese_racial`) ficam sob `purificacao` em `records.jsonl`; `validate_schemas.py` deve
passar antes de qualquer commit.

### Schemas de referência

#### MasterRecord (simplificado)

Schema canônico: `tools/schemas/master-record.schema.json`; o bloco `iconocode` segue
`iconocode-output.schema.json`, e o bloco `purificacao`, o codebook (Anexo 4, `references/anexo-4-regimes-recusas-inventario.md`).

```json
{
  "master_record_version": "1.0.0",
  "batch_id": "uuid",
  "item_id": "uuid",
  "item_hash": "sha256",
  "input": {
    "input_url": "https://...",
    "title_hint": "...",
    "date_hint": "...",
    "place_hint": "..."
  },
  "webscout": {
    "query": {"query_type": "seed|item", "target": "...", "constraints": {}},
    "search_results": [],
    "summary_evidence": "...",
    "gaps": []
  },
  "iconocode": {
    "pre_iconographic": [],
    "codes": [],
    "interpretation": [],
    "validation": {"claim_ledger": []},
    "confidence": 0.0
  },
  "exports": {
    "abnt_citations": [],
    "audit_flags": []
  },
  "timestamps": {"created_at": "ISO-8601", "updated_at": "ISO-8601"}
}
```

#### Ordenação de resultados de busca (WebScout)

Ordena candidatos encontrados na busca para triagem; não mede evidência nem descreve a
imagem.

`final_score = 0.25*term_overlap + 0.20*period_match + 0.15*geo_match + 0.15*authority + 0.15*metadata_completeness + 0.10*cross_source_agreement`

Boosts: `+0.05` para registro institucional canônico; `+0.05` para IIIF/PID.
Penalidades: `-0.10` para contradição de metadados; `-0.10` para links mortos.

#### Validation policy (IconoCode)

A heurística histórica por quantidade de fontes foi superada pela crítica de adequação,
independência e alcance descrita em `metodo-e-fontes.md`. Respeitar os estados admitidos pelo
schema sem promover claims por contagem; contradição não resolvida permanece explícita.
